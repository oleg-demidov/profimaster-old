<?php


/**
 * Description of CreateTable
 *
 * @author oleg
 */

class PluginFreelancer_Update_CreateTable extends ModulePluginManager_EntityUpdate {
	/**
	 * Выполняется при обновлении версии
	 */
    public function up() {
	$aResult = true;
        if (!$this->isTableExists('prefix_freelancer_order_bid')) {
            if(!$this->exportSQL(Plugin::GetPath(__CLASS__).'update/1.0.0/dump_bid.sql')){
                $aResult[] = false;
            }
        }
        if (!$this->isTableExists('prefix_freelancer_order')) {
            if(!$this->exportSQL(Plugin::GetPath(__CLASS__).'update/1.0.0/dump_order.sql')){
               $aResult[] = false;
            }
        }
        return !in_array(false,$aResult);
    }

	/**
	 * Выполняется при откате версии
	 */
	public function down() {
            if ($this->isTableExists('prefix_freelancer_order')){
		$this->exportSQLQuery('DROP TABLE IF EXISTS prefix_freelancer_order');
            }
            if ($this->isTableExists('prefix_freelancer_order_bid')){
		$this->exportSQLQuery('DROP TABLE IF EXISTS prefix_freelancer_order_bid');
            }
	}
}