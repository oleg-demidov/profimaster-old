<?php

/**
 * Запрещаем напрямую через браузер обращение к этому файлу
 */
if (!class_exists('Plugin')) {
    die('Hacking attempt!');
}

class PluginFreelancer extends Plugin {

    private $aProperties=array(
        array(
            'data'=>array(
                'type'=>ModuleProperty::PROPERTY_TYPE_TEXT,
                'title'=>'Номер',
                'code'=>'number',
                'sort'=>100
            ),
            'validate_rules'=>array(
                'allowEmpty'=>false,
                'max' => 15,
                'min' => 10,                
            ),
            'params'=>array(),
            'additional'=>array()
        )
    );
    
    protected $aInherits = array(
        'template' => array(
            'component.nav.nav' => '_components/nav/nav.tpl',
            'component.auth.registration' => '_components/auth/auth.registration.tpl',
            'component.auth.login' => '_components/auth/auth.login.tpl',
            //'component.media.pane' => '_components/media/pane.tpl',
           // 'admin:component.p-rbac.role-permissions-item' => '_components/p-rbac/role/permissions.item.tpl',
        ),
        /*'entity'  =>array(
            'ModuleComment_EntityComment' => '_ModuleComment_EntityComment',
            ),*/
        'action' => ['ActionSettings' => '_ActionSettings'],
        'module' => [
            'ModuleMedia' => '_ModuleMedia',
            'ModuleUser' => '_ModuleUser'],
        'entity' =>array(
            'ModuleUser_EntityUser' => '_ModuleUser_EntityUser',
            'ModuleMedia_EntityMedia' => '_ModuleMedia_EntityMedia'
            ),
        'mapper' =>array('ModuleUser_MapperUser' => '_ModuleUser_MapperUser')
    );
    
    protected $aRoles = array(
        'groups' => array(
            array('freelancer', 'Фрилансер'),
        ),
        'roles' => array(
            array('profi', 'Profi'),
            array('master', 'Master'),
            array('employer', 'Заказчик'),
            array('employer_vip', 'Заказчик VIP')
        ),
        'permissions' => array(
            /*
             * Роль
             */
            array(
                'employer',
                'Заказчик',
                'msg_error' => 'plugin.freelancer.errors.is_employer',
                'group' => 'freelancer',
                'roles' => array('employer')),
            
             array(
                'master',
                'Мастер',
                'msg_error' => 'plugin.freelancer.errors.is_master',
                'group' => 'freelancer',
                'roles' => array('master')),
            
            /*
             * Специализация моя
             */
            array(
                'specialization',
                'Выбор специализации',
                'msg_error' => 'plugin.freelancer.errors.specialization',
                'group' => 'freelancer',
                'roles' => array('master')),
            
            /*
             *  Заявки
             */
            array(
                'create_order',
                'Создание заявок',
                'msg_error' => 'plugin.freelancer.errors.create_order',
                'group' => 'freelancer',
                'roles' => array('user')),            
            array(
                'view_order',
                'Просмотр заявок',
                'msg_error' => 'plugin.freelancer.errors.view_order',
                'group' => 'freelancer',
                'roles' => array('user', 'guest')),
            array(
                'order_search',
                'Поиск по заявкам',
                'msg_error' => 'plugin.freelancer.errors.no_order_search',
                'group' => 'freelancer',
                'roles' => array('user')),
            array(
                'orders_top',
                'Установка заявок в топ',
                'msg_error' => 'plugin.freelancer.errors.no_orders_top',
                'group' => 'freelancer',
                'roles' => array('user')),
            
            /*
             * Отклики на заявку
             */
            array(
                'create_bid',
                'Создание отклика на заявку',
                'msg_error' => 'plugin.freelancer.errors.no_create_response',
                'group' => 'freelancer',
                'roles' => array('master')),
            array(
                'view_bid',
                'Просмотр откликов не разрешен',
                'msg_error' => 'plugin.freelancer.errors.no_view_response',
                'group' => 'freelancer',
                'roles' => array('profi', 'master')),
            
            
            /* array(
                'view_ankets_contacts',
                'Просмотр контактов мастеров',
                'msg_error' => 'plugin.freelancer.errors.no_view_contacts_ankets',
                'group' => 'freelancer',
                'roles' => array('user', 'guest', 'client', 'client_vip')),
            array(
                'bid_count_day',
                'Количество ответов на заявки в день',
                'msg_error' => 'plugin.freelancer.errors.done_bids',
                'group' => 'freelancer',
                'roles' => array('profi', 'master', 'user')),
            
            array(
                'add_portfolio',
                'Создание заявок',
                'msg_error' => 'plugin.freelancer.errors.add_portfolio',
                'group' => 'freelancer',
                'roles' => array('profi', 'master', 'user')),
            array(
                'notif_email_orders',
                'Оповещение о заявках на email',
                'msg_error' => 'plugin.freelancer.errors.notif_email_orders',
                'group' => 'freelancer',
                'roles' => array('profi', 'master', 'user')),
            array(
                'notif_sms_orders',
                'Оповещение о заявках по sms',
                'msg_error' => 'plugin.freelancer.errors.notif_sms_orders',
                'group' => 'freelancer',
                'roles' => array('profi', 'master')),
            array(
                'notif_email_bids',
                'Оповещение об ответах на заявки по email',
                'msg_error' => 'plugin.freelancer.errors.notif_email_bids',
                'group' => 'freelancer',
                'roles' => array('client', 'client_vip')),
            array(
                'notif_sms_bids',
                'Оповещение об ответах на заявки по sms',
                'msg_error' => 'plugin.freelancer.errors.notif_sms_bids',
                'group' => 'freelancer',
                'roles' => array('client', 'client_vip')),
            array(
                'ads_direct',
                'Установка обьявления ydirect',
                'msg_error' => 'plugin.freelancer.errors.ads_direct',
                'group' => 'freelancer',
                'roles' => array('profi', 'master')),
            array(
                'top_freelancer',
                'Установка анкеты в топе выдачи',
                'msg_error' => 'plugin.freelancer.errors.top_freelancer',
                'group' => 'freelancer',
                'roles' => array('profi', 'master')),
            array(
                'lux_masters',
                'Установка анкеты в боке Лучшие мастера',
                'msg_error' => 'plugin.freelancer.errors.lux_masters',
                'group' => 'freelancer',
                'roles' => array('profi', 'master')),*/
        ),
    );
    
    protected $aRolesRemove = array(
        'groups' => array('freelancer'),
        'roles' => array('profi', 'master', 'client', 'client_vip')
    );
    
    public function Activate() {
        
        if (!$this->Rbac_CreatePermissions($this->aRoles, 'freelancer')) {
            return false;
        }
        
        if (!$oType = $this->Category_CreateTargetType('specialization', 'Специализации', array(), true)) {
            $this->Message_AddError('Ошибка создания типа категории','',true);
            return false;
        }
        
        $oCategory = Engine::GetEntity('Category_Category');
        $oCategory->setTypeId($oType->getId());
        $oCategory->setTitle('Строймастер');
        $oCategory->setDescription('Строительство и ремонт');
        $oCategory->setUrl('stroymaster');
        $oCategory->setDateCreate(date("Y-m-d H:i:s"));
        $oCategory->setUrlFull('stroymaster');
        $oCategory->setOrder(1);
        $oCategory->setData([]);
        if (!$oCategory->Save()){
            $this->Message_AddError('Ошибка создания временной категории','',true);
            return false;
        }
        return true;
    }

    /**
     * Инициализация плагина
     */
    public function Init() {
        $this->Geo_AddTargetType('order');
        //$this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump.sql');
        $this->Media_AddTargetType('order');
        $this->Media_AddTargetType('user');
        $this->Component_Add('freelancer:auth');
    }

    /**
     * Проверка зависимостей плагина
     *
     * @return bool
     */
    public function Deactivate() {
        $this->Rbac_RemovePermissions($this->aRolesRemove, 'freelancer');
        $this->Category_RemoveTargetType('specialization', ModuleCategory::TARGET_STATE_NOT_ACTIVE);
        return true;
    }

}

?>