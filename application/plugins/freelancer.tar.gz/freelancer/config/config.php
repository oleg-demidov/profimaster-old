<?php

Config::Set('router.page.fauth', 'PluginFreelancer_ActionFauth');
Config::Set('router.page.order', 'PluginFreelancer_ActionOrder');
Config::Set('router.page.freelancer', 'PluginFreelancer_ActionFreelancer');
//Config::Set('router.page.employer', 'PluginFreelancer_ActionEmployer');
Config::Set('module.comment.vote_target_allow', array_merge(Config::Get('module.comment.vote_target_allow'),['order']));
//$config['module']['comment']['vote_target_allow']

$config['table']=[
    'order' => '___db.table.prefix___freelancer_order'
];

$config['poisk'] = [
    'per_page' => 10,
    'count_page_line' => 2,
    'geo' => [
        'countries' => ['KZ']
        ],
    'item_desc_words' => 20
    ];
    
$config['menu'] = [
  'orders_pos' => 2,
  'masters_pos' => 5
];

$config['response'] = [
    'per_page' => 10,
    'pagination'=>[
        'pages_count' => 5
        ],
    'max_level' => 1
];

return $config;