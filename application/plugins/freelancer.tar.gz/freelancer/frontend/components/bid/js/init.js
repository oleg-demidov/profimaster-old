$(document).ready(function ($) {
    
    
    $('.fl-bid-item').flBidEdit({
        urls: {
            remove:  aRouter['order'] + 'ajaxbidremove',
            get_form:  aRouter['order'] + 'ajaxbidform'
        }
    });
});