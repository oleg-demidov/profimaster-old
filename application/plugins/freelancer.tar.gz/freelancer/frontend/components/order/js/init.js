jQuery(function($) {
    $('.js-my-slider').lsSlider();
    $('.js-confirm-remove-order').lsModal();
    $('.js-order-remove-button-toggle').lsModalToggle();
});