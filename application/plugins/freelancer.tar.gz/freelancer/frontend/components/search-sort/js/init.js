

jQuery(function ($) {
    $('.js-order_buttons button').click(function(){
        $('.js-order_buttons button').removeClass('ls-button--primary');
        $('input[name="order"]').remove();
        $(this).addClass('ls-button--primary');
        $('form').append('<input type="hidden" name="order" value="'+$(this).val()+'"/>');
    })
});