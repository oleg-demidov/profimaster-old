$(document).ready(function(){
    console.log($('.specialization select'))
    $('.specialization select').addClass('selectpicker').selectpicker({
        actionsBox:true
    });
});