$(document).ready(function(){
   $('.js-specializations-tabs').lsTabs();
   $('.js-specializations-tabs input:checked').each(function(){
       $('form').append('<input name="specialization[]" class="input_hidden" value="'+$(this).attr('value')+'">');
   })
   $('.js-specializations-tabs input').change(function(){ console.log($(this).attr('value'))
        if($(this).prop("checked")){
            $('form').append('<input name="specialization[]" class="input_hidden" value="'+$(this).attr('value')+'">');
        }else{
            $('input.input_hidden[value="'+$(this).attr('value')+'"]').remove();
        }
   });
});