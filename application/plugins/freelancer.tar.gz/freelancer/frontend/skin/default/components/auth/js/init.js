 jQuery(document).ready(function($){
     $('.js-freelancer-form-validate').parsley();
     
     $('[data-type=recaptcha]').livequery(function () {
        $(this).lsReCaptcha({
            key: ls.registry.get('recaptcha.site_key')
        });
    });
    
    $('.js-freelancer-auth-login-form').on('submit', function (e) {
        ls.ajax.submit(aRouter.fauth + 'ajax-login', $(this), function ( response ) {
            response.sUrlRedirect && (window.location = response.sUrlRedirect);
        });

        e.preventDefault();
    });
 });
 
