
jQuery(document).ready(function ($) {

// Комментарии
    
    $('.js-comments-order').lsComments({
        urls: {
            add:  aRouter['order'] + 'ajaxaddcomment/',
            load: aRouter['order'] + 'ajaxresponsecomment/'
        }
    });
    
    
});