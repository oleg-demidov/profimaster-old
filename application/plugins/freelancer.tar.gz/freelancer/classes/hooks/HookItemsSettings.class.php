<?php

class PluginFreelancer_HookItemsSettings extends Hook
{

    public function RegisterHook()
    {
            $this->AddHook('template_nav_freelancer_settings', 'ItemsSettings' ,__CLASS__);
            // $this->AddHook('template_comment_form_fields_after', 'CommentProperty' ,__CLASS__);
    }
    
    public function ItemsSettings($aParams){
        
        if(!$this->Rbac_IsAllow('specialization', 'freelancer',['no_stat'=> true, 'count' => 1])){
            return ;
        }
        $aNewItems = [
            [ 
                'url' => Router::GetPath('settings/specialization'), 
                'text' => $this->Lang_Get('plugin.freelancer.text.specialization'), 
                'name' => 'specialization' ]
            
        ];
        return array_merge($aNewItems, $aParams['items']);
    }
    
}