<?php
/**
 * LiveStreet CMS
 * Copyright © 2013 OOO "ЛС-СОФТ"
 *
 * ------------------------------------------------------
 *
 * Official site: www.livestreetcms.com
 * Contact e-mail: office@livestreetcms.com
 *
 * GNU General Public License, version 2:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * ------------------------------------------------------
 *
 * @link http://www.livestreetcms.com
 * @copyright 2013 OOO "ЛС-СОФТ"
 * @author Maxim Mzhelskiy <rus.engine@gmail.com>
 *
 */

/**
 * Хуки
 */
class PluginFreelancer_HookMain extends Hook
{
    /**
     * Регистрация необходимых хуков
     */
    public function RegisterHook()
    {
        /**
         * Хук на отображение админки
         */
        $this->AddHook('init_action_admin', 'InitActionAdmin');
        /**
         * Хук на главное меню сайта
         */
        $this->AddHook('template_nav_freelancer_main', 'NavMain', null, 655);
        
       
        $this->AddHook('template_nav_userbar_nav', 'UserbarNav', null, 655);
    }

    /**
     * Добавляем в главное меню админки свой раздел с подпунктами
     */
    public function InitActionAdmin()
    {
        /**
         * Получаем объект главного меню
         */
        $oMenu = $this->PluginAdmin_Ui_GetMenuMain();
        /**
         * Добавляем новый раздел
         */
        $oMenu->AddSection(
            Engine::GetEntity('PluginAdmin_Ui_MenuSection')->SetCaption($this->Lang_Get('plugin.freelancer.admin.title'))->SetName('freelancer')->SetUrl('plugin/freelancer')->setIcon('user')
                ->AddItem(Engine::GetEntity('PluginAdmin_Ui_MenuItem')->SetCaption($this->Lang_Get('plugin.freelancer.admin.menu.orders'))->SetUrl('orders'))
                ->AddItem(Engine::GetEntity('PluginAdmin_Ui_MenuItem')->SetCaption($this->Lang_Get('plugin.freelancer.admin.menu.bids'))->SetUrl('bids'))
                //->AddItem(Engine::GetEntity('PluginAdmin_Ui_MenuItem')->SetCaption($this->Lang_Get('plugin.freelancer.admin.menu.responses'))->SetUrl('responses'))
        );
    }

    /**
     * Добавляем пункты в главное меню
     *
     * @param $aParams
     *
     * @return array
     */
    public function NavMain($aParams)
    {
        
        $aResult = array();
        /*foreach($aParams['items'] as $k => $aItem){
            if($aItem['name'] == 'people'){
                unset($aParams['items'][$k]);
            }
        }*/
        //foreach ($aPages as $oPage) {
            $aResult = [
            [
                'text' => $this->Lang_Get('plugin.freelancer.menu.orders'),
                'url'  => Router::GetPathRootWeb().'/order/search',
                'name' => 'order_search',
            ],
            [
                'text' => $this->Lang_Get('plugin.freelancer.menu.masters'),
                'url'  => Router::GetPathRootWeb().'/freelancer/search',
                'name' => 'freelancer_search',
            ]            
            ];
        //}
        return array_merge(  $aResult,$aParams['items']);
    }
    
    public function UserbarNav($aParams)
    {
        $oUserCurrent = $aParams['params']['user'];
        if(!$oUserCurrent){
            return $aParams['items'];
        }
        if($oUserCurrent->isAdministrator() or $this->Rbac_IsAllow('create_order','freelancer',['no_stat' => true])){
            $aResult = array();
           //print_r($aParams['items'][0]['menu']['items']);
            $aParams['items'][0]['menu']['items'][] = [
                'text' => $this->Lang_Get('plugin.freelancer.menu.orders'),
                'url'  => Router::GetPathRootWeb().'/order/list/user'.$oUserCurrent->getId(),
                'name' => 'create_order',
            ];

            $aParams['items'][1]['menu']['items'][] = [
                'text' => $this->Lang_Get('plugin.freelancer.menu.create_order'),
                'url'  => Router::GetPathRootWeb().'/order/add',
                'name' => 'create_order',
            ];
        }
        return array_merge(  $aParams['items']);
    }
}