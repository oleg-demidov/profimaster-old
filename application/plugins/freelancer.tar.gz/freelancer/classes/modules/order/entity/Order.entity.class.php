<?php


class PluginFreelancer_ModuleOrder_EntityOrder extends EntityORM
{
    protected $aBehaviors=array(
        // Настройка категорий
        'category'=>array(
            'class'=>'ModuleCategory_BehaviorEntity',
            'target_type'=>'specialization',
            'form_field'=>'specialization[]',
            'multiple'=>true,
            'validate_enable'=>false,
            'object_type' => 'order',
            'classes' => 'specialization'
        ),
        'media'=>array(
            'class'=>'PluginFreelancer_ModuleMedia_BehaviorEntity',
            'target_type'=>'order'
        ),
        'ygeo' =>array(
            'class'=>'PluginYdirect_ModuleGeo_BehaviorEntity',
            'target_type'=>'order'
        ),
    );
    
    protected $aValidateRules=array(
        // Используем стандартный валидатор String
        array('text_about','string','max'=>2000,'min'=>20, 'allowEmpty' => false),
        // Реализуем свою валидацию методом ValidateMy
        array('budjet','number','max'=>200000000,'min'=>1, 'allowEmpty' => false),
        
        array('specialization','specialization'),
       // array('_geo_target','geo'),
        array("title", 'string', 'max'=>100, 'min'=>3, 'allowEmpty' => false)
    );
    
    public function ValidateGeo(){
        if(!$oGeoObject = $this->getGeoObject()){
            return $this->Lang_Get('plugin.freelancer.errors.no_region');
        }
    	if(!$oGeoObject->getRegion() ){
              return $this->Lang_Get('plugin.freelancer.errors.no_region');
        }
        return true;
    }
    
    public function ValidateSpecialization($sValue) {
        $aSpec = $this->Category_GetCategoryItemsByFilter(['id in' => $sValue, '#index-from-primary']);
        if($iCount = sizeof($aSpec)){
            $this->_setData(array('_categories_for_save' => array_keys($aSpec)));
            return true;
        }
        //print_r($this);
        return $this->Lang_Get('plugin.freelancer.errors.one_spec');
    }
    protected $aRelations = array(
        'user'=>array(EntityORM::RELATION_TYPE_BELONGS_TO,'ModuleUser_EntityUser','user_id'),
        'master'=>array(EntityORM::RELATION_TYPE_BELONGS_TO,'ModuleUser_EntityUser','master_id'),
        'bids'=>array(EntityORM::RELATION_TYPE_HAS_MANY,'PluginFreelancer_ModuleOrder_EntityBid','order_id'),
    );
    
    protected function beforeSave()
    {
        if ($bResult = parent::beforeSave()) {
            if($this->_isNew()){
                if($this->User_GetUserCurrent()->isAdministrator()){
                    return $bResult;
                }
                if(!$bResult = $this->Rbac_IsAllow('create_order','freelancer')){
                    $this->Message_AddError($this->Rbac_GetMsgLast());
                }
            }
        }
        return $bResult;
    }
    
    protected function afterDelete() {
        $aBids = $this->getBids();
        foreach($aBids as $oBid){
            $oBid->Delete();
        }
    }
     
    public function setGeoData($aGeo){
        
        $oGeoTarget = Engine::GetEntity('Geo_Geo');
    	 if (isset($aGeo['city']) && $aGeo['city']) {
                $oGeoObject = $this->Geo_GetGeoObject('city', (int)$aGeo['city']);
            } elseif (isset($aGeo['region']) && $aGeo['region']) {
                $oGeoObject = $this->Geo_GetGeoObject('region', (int)$aGeo['region']);
            } elseif (isset($aGeo['country']) && $aGeo['country']) {
                $oGeoObject = $this->Geo_GetGeoObject('country', (int)$aGeo['country']);
            } else {
                $oGeoObject = null;
            }
          $this->setGeoObject($oGeoObject);
          
          return $oGeoTarget;
    }
    
        
    public function _getUrlEdit() {
        return Config::Get('path.root.web').'/order/edit/'.$this->getOrderId();
    }
    
    public function _getUrlView() {
        return Config::Get('path.root.web').'/order/'.$this->getOrderId();
    }
    
    public function _isAllowEdit() {
        if($oUser = $this->User_GetUserCurrent()){
            return ($oUser->getId() == $this->getUserId() or $oUser->isAdministrator());
        }
        return false;
    }
    
    
    public function getCountCommentsRoot() 
    {
       return $this->Comment_GetCountCommentsRootByTargetId($this->getOrderId(), 'order');
            
    }
    public function getCropText() {
        return func_text_words($this->getTextAbout(), Config::Get('plugin.freelancer.poisk.item_desc_words'));
    }
    public function isCanBid() {
        if($this->PluginFreelancer_Order_GetBidByOrderIdAndUserId($this->getId(), $this->User_GetUserCurrent()->getId())){
            return false;
        }
        return $this->Rbac_IsAllow('create_bid','freelancer',['no_stat'=>true]);
    }
}