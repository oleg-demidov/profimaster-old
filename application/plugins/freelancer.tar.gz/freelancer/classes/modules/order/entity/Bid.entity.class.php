<?php


class PluginFreelancer_ModuleOrder_EntityBid extends EntityORM
{
    protected $aBehaviors=array(
        
    );
    
    protected $aValidateRules=array(
        array('text','bid_text','max'=>2000,'min'=>10),
        array('price','number','max'=>200000000,'min'=>1),
    );
    
    protected $aRelations = array(
        'user'=>array(EntityORM::RELATION_TYPE_BELONGS_TO,'ModuleUser_EntityUser','user_id'),
        'order'=>array(EntityORM::RELATION_TYPE_BELONGS_TO, 'PluginFreelancer_ModuleOrder_EntityOrder','order_id'),
    );
    public function ValidateBidText($sValue) {
        if (!func_check($sValue, 'text', 2, 10000)) {
            return $this->Lang_Get('topic.comments.notices.error_text');            
        }
        return true;
    }
    
    public function _isAllowEdit($oUser = '') {
        if(!$oUser){
            $oUser = $this->User_GetUserCurrent();
        }
        if($oUser){
            return ($oUser->getId() == $this->getUserId() or $this->oUserCurrent->isAdministrator());
        }
        return false;
    }
    public function getTextCrop($iCount) {
        return func_text_words($this->getText(), $iCount);
    }
}