<?php


class PluginFreelancer_ModuleUser_EntityUser extends PluginFreelancer_Inherit_ModuleUser_EntityUser
{
    /*
     * Если установить не подцепляется relation в ORM
     */
    protected $aBehaviors=array(
        // Настройка категорий
        'category'=>array(
            'class'=>'ModuleCategory_BehaviorEntity',
            'target_type'=>'specialization',
            'form_field'=>'specialization',
            'multiple'=>true,
            'validate_require'=>false,
            'validate_min'=>1,
            'validate_max'=>500,
            'validate_only_without_children'=>false,
            'validate_from_request'=>false,
            'object_type' => 'user',
            'classes' => 'specialization'
        ),
        'ygeo' => [
            'class' => 'PluginYdirect_ModuleGeo_BehaviorEntity',
            'target_type' => 'user'
        ]
    );
    public function _getPrimaryKeyValue()
    {
        return $this->getId();
    }
    
    protected $aValidateRules = array(
        array('login', 'login', 'on' => array('registration', 'freelancer_reg','login', '')), // '' - означает дефолтный сценарий
        array('login', 'login_exists', 'on' => array('registration', 'freelancer_reg','login')),
        array('email_or_number', 'email_or_number', 'allowEmpty' => false, 'on' => array( 'freelancer_reg')),
        array('role', 'role', 'on' => array( 'freelancer_reg')),
        array('mail', 'email', 'allowEmpty' => false, 'on' => array('registration','')),
        array('mail', 'mail_exists', 'on' => array('registration')),
        array('specialization', 'specialization', 'on' => array('specialization')),
    );
    
    public function ValidateSpecialization($sValue, $aParams)
    {
        if(!is_array($sValue)){
            return true;
        }
        if(!$this->Rbac_IsAllow('specialization', 'freelancer', ['count' => sizeof($sValue)])){
            return $this->Rbac_GetMsgLast();
        }
        return true;
    }
    
    public function ValidateEmailOrNumber($sValue, $aParams)
    {
        if (!$this->Validate_Validate('email', $sValue)) {
            $sNumer = str_replace(['(',')',' ','-',',','.','+'], '', trim($sValue));
            if(!$this->User_IsNumber($sValue)){
                return 'Поле "Email или Номер" не соответствует Email и Номеру';
            }elseif($this->User_NumberIsExits($sNumer)){
                return 'Такой номер занят';
            }else{
                $this->setNumber($sNumer);
            }
        }elseif($this->User_GetUsersByFilter(['email' => $sValue])){
            return 'Такой Email занят';
        }else{
            $this->setEmail($sValue);        
        }
        return true;
    }
    
    public function ValidateRole($sValue, $aParams)
    {
        $this->Logger_Notice($sValue);
        $aRoleAllow = ['master','employer'];
        if(!in_array( $sValue, $aRoleAllow)){
            return "Выберете вашу роль";
        }
        return true;
    }
    
    public function getNumber() {
        $aValues = $this->User_getUserFieldValueByName($this->getId(), 'phone');
        return $aValues;
    }
    
    public function getCountOrdersDone() {
       return $this->PluginFreelancer_Order_GetCountDoneOrdersByUserId($this->getId());        
    }
}