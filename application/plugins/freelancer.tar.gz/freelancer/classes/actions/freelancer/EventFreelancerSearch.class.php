<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionFreelancer_EventFreelancerSearch extends Event {

    public function EventSearch() 
    {
        if(!$this->Rbac_IsAllow('order_search', 'freelancer')){
            $this->Message_AddError($this->Lang_Get($this->Rbac_GetMsgLast()),[],true);
            Router::LocationAction('error');
        }
        
        $sOrd =[];
        if(in_array($sOrder = getRequest('order'),  ['price_desc','price_asc','rating_desc','rating_asc'])){
            $aOrd = [
                'price_desc' => ['p.budjet' => 'desc'],
                'price_asc' => ['p.budjet' => 'asc'],
                'rating_desc' => ['user_rating' => 'desc'],
                'rating_asc' => ['user_rating' => 'asc']
            ];
            $sOrd = $aOrd[getRequest('order')];
        }
        
        $iPage = $this->GetParamEventMatch(0, 2) ? $this->GetParamEventMatch(0, 2) : 1;
        $aFilter = array(
            'activate' => 1
        );
        
        if($aGeoRequest = getRequest('geo')){
            if ($aGeoRequest['city']) {
            $aFilter['geo_city'] = $aGeoRequest['city'];
            } elseif ($aGeoRequest['region']) {
                $aFilter['geo_region'] = $aGeoRequest['region'];
            } elseif ($aGeoRequest['country']) {
                $aFilter['geo_country'] = $aGeoRequest['country'];
            }
        }
        
        $aFilter['#category'] = getRequest('specialization');
        
        $aFilter['#page'] = $iPage;
        
        $aFilter["#order"] = $sOrd;
        
        $aFreelancers = $this->User_GetUsersByFilter($aFilter, $sOrd, $iPage ,Config::Get('plugin.freelancer.poisk.per_page') );
        
        //$aOrdersTop = $this->getOrdersTop($aOrders['collection']);
        
        $aPaging = $this->Viewer_MakePaging($aFreelancers['count'], $iPage, Config::Get('plugin.freelancer.poisk.per_page'),
            Config::Get('plugin.freelancer.poisk.count_page_line'), Router::GetPath('freelancer/search'), $_REQUEST);

        $this->Viewer_Assign('sActionUrl', Router::GetPath('freelancer/search'));
        $this->Viewer_Assign('aPaging', $aPaging);
       //$this->Viewer_Assign('aOrdersTop',$aOrdersTop);
        $this->Viewer_Assign('aFreelancers',$aFreelancers['collection']);
        $this->SetTemplateAction('search');
    }
    
    public function getOrdersTop(&$aOrders) {
        $aOrdersTop =[];
        foreach($aOrders as $oOrder){
            if($this->Rbac_IsAllowUser($oOrder->getUser(),'orders_top', 'freelancer')){
                $aOrdersTop[] = $oOrder;
            }
        }
        return $aOrdersTop;
    }
    
    
}