<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionOrder_EventOrderSearch extends Event {

    public function EventSearch() 
    {
        $this->Component_Add('freelancer:specialization-tabs');
        $this->Component_Add('freelancer:order');
        $this->Component_Add('freelancer:search-sort');
        $this->Component_Add('freelancer:search');
        $this->Component_Add('freelancer:user');

        
        if(!$this->Rbac_IsAllow('order_search', 'freelancer')){
            $this->Message_AddError($this->Lang_Get($this->Rbac_GetMsgLast()),[],true);
            Router::LocationAction('error');
        }
        
        $aFilter = [];
        $iUserTopIds = $this->Rbac_GetUsersByPermissionCode('orders_top');
        $aFilter['#where']['t.user_id not in (?a)'] = [$iUserTopIds];
        
        $aOrder =[];
        $aOrderList = [
            'price_desc' => ['t.budjet' => 'desc'],
            'price_asc' => ['t.budjet' => 'asc'],
            'rating_desc' => ['u.user_rating' => 'desc'],
            'rating_asc' => ['u.user_rating' => 'asc'],
        ];
        if(in_array($sOrder = getRequest('order'), array_keys($aOrderList))){
            $aOrder = array_merge($aOrderList[getRequest('order')], $aOrder);
        }        
        $aFilter['#order'] = $aOrder;
        
        $iPage = $this->GetParamEventMatch(0, 2) ? $this->GetParamEventMatch(0, 2) : 1;
        $aFilter['#page'] = array($iPage, Config::Get('plugin.freelancer.poisk.per_page'));
        
        $aOrders = $this->getOrders($aFilter);
        
        
        $aFilter = [];
        $aFilter['#order'] = $aOrder;
        $aFilter['#where']['t.user_id in (?a)'] = [$iUserTopIds];
        $aOrdersTop = $this->getOrders($aFilter);
        
        $aPaging = $this->Viewer_MakePaging($aOrders['count'], $iPage, Config::Get('plugin.freelancer.poisk.per_page'),
            Config::Get('plugin.freelancer.poisk.count_page_line'), Router::GetPath('order/search'), $_REQUEST);
        
        

        $this->Viewer_Assign('sActionUrl', Router::GetPath('order/search'));
        $this->Viewer_Assign('paging', $aPaging);
        $this->Viewer_Assign('aOrdersTop',$aOrdersTop);
        $this->Viewer_Assign('aOrdersCount',$aOrders['count']+$aOrdersTop['count']);
        $this->Viewer_Assign('aOrders',$aOrders['collection']);
        $this->SetTemplateAction('search/search');
    }
    
    private function getOrders($aFilter) {
        
        $aFilter['#with'] = ['user','#category'];
        $aFilter['#category'] = getRequest('specialization');
        $aFilter["#join"][] = $this->PluginFreelancer_Order_GetGeoFilter(getRequest('geo'));
        $aFilter['#where']['t.status != ?'] = ['new'];
        
        $this->Hook_Run('freelancer_event_search_order', ['filter' => &$aFilter]);
        
        $aFilter['#join'][] = " JOIN ".Config::Get('db.table.user')." u on t.user_id = u.user_id";
        
        //print_r($aFilter);        
        
        return $this->PluginFreelancer_Order_GetOrderItemsByFilter($aFilter);
    }
    
    
}