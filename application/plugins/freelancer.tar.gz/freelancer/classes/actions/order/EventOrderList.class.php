<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionOrder_EventOrderList extends Event {

    public function EventList() 
    {
        $this->Component_Add('freelancer:order');
        $iUserId =  $this->GetParamEventMatch(0, 1);
        $aOrders = $this->PluginFreelancer_Order_GetOrderItemsByUserId($iUserId);
        $this->Viewer_Assign('aOrders', $aOrders);
    } 
    
}