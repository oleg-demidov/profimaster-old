<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionOrder_EventResponse extends Event {

    
    public function EventEdit() 
    {
        if(!$this->oUserCurrent){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_auth'),[],true);
            Router::LocationAction('error');
        }
           
        $iIdResp = $this->GetParam(2);
        if(!$oResponse = $this->PluginFreelancer_Order_GetResponseByFilter( array('response_id' => $iIdResp) )){
            $oResponse = Engine::GetEntity('PluginFreelancer_ModuleOrder_EntityResponse');
            $this->canCreateResponse($oResponse);
        }else{
            $this->canEditResponse($oResponse);
        }
        
        $iIdOrder = (int)$this->sCurrentEvent;
        if(!$oOrder = $this->PluginFreelancer_Order_GetOrderByFilter( array('order_id' => $iIdOrder) )){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_order'),[],true);
            Router::LocationAction('error');
        }
   
        if(isPost()){   
            
            $oResponse->setText( getRequest('text') );
            
            $oResponse->setPrice( getRequest('price') );
            
            $oResponse->setUserId( $this->oUserCurrent->getId());
            
            $oResponse->setOrderId( $oOrder->getOrderId());
            
            $oResponse->setProperties(getRequest('property'));
            
            if($oResponse->_Validate()){   
                if($oResponse->Save()){
                    Router::LocationAction($this->sCurrentAction.'/'.$oOrder->getOrderId());
                }
            }else{
                foreach ($oResponse->_getValidateErrors() as $sError){
                    $this->Message_AddError($sError[0]);
                }
            }
            
        }
        
        $oUser = $this->User_GetUserById($oOrder->getUserId());
        
        $this->Viewer_Assign('oUser', $oUser);
        
        $this->Viewer_Assign('oOrder', $oOrder);
        
        $this->Viewer_Assign('oResponse', $oResponse);
        
        $this->SetTemplateAction('response/add');
        
    }   
    
    public function EventСhoose() {
        $iIdOrder = (int)$this->sCurrentEvent;
        $iIdResp = $this->GetParam(1);
        
        if( !$oOrder = $this->PluginFreelancer_Order_GetOrderByOrderId($iIdOrder) ){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_order'),[],true);
            Router::LocationAction('error');
        }
        
        if( !$oResponse = $this->PluginFreelancer_Order_GetResponseByResponseId($iIdResp)  ){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_response'),[],true);
            Router::LocationAction('error');
        }
        if(!$oOrder->_isAllowEdit()){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.noallow_edit'),[],true);
            Router::LocationAction('error');
        }
        $oOrder->setMasterId($oResponse->getUserId());
        $oOrder->Save();
        Router::LocationAction('order/'.$oOrder->getOrderId());
        $this->SetTemplate(false);
    }
    
    public function canCreateResponse(&$oResponse) {
        if($this->oUserCurrent->isAdministrator()){
            return true;
        }
        if($this->Storage_Get('response_create')){
            $oResponse->_setData(['_create_response' => 1]);
            return true;
        }
        if(!$this->Rbac_IsAllow('response_create','freelancer')){
            $this->Message_AddError($this->Rbac_GetMsgLangPermissions(),[],true);
            Router::LocationAction('error');
        }
        $this->Storage_Set('response_create', 1);
        $oResponse->_setData(['_create_response' => 1]);
        return true;
    }
    
    public function canEditResponse($oResponse) {
        if(!$oResponse->_isAllowEdit()){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.noallow_edit'),[],true);
            Router::LocationAction('error');
        }
    }
    
    public function canViewResponse($oResponse) {
        if($this->canEditResponse($oResponse)){
            return true;
        }
        if(!$this->Rbac_IsAllow('view_response','freelancer')){
            $this->Message_AddError($this->Rbac_GetMsgLangPermissions(),[],true);
            Router::LocationAction('error');
        }
        return true;
    }
  
    
    
}