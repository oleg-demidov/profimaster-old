<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionOrder_EventOrder extends Event {

    public function EventView() 
    {
        $this->Component_Add('freelancer:order');
        $this->Component_Add('freelancer:bid');
        $this->Component_Add('freelancer:user');
        
    		
        $iIdOrder = (int)$this->sCurrentEvent;
        if(!$oOrder = $this->PluginFreelancer_Order_GetOrderByOrderId($iIdOrder)){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_page'),[],true);
            Router::LocationAction('error');
        }
        $this->Viewer_AddBlock('right', 'component@freelancer:user.employer-side',['oUser' => $oOrder->getUser()]);
        $this->Hook_Run('freelancer_order_edit', ['oOrder' => &$oOrder]);
        $oOrder->setDateRead(date ('Y-m-d G:i:s'));
        $oOrder->Save();
        
        $this->Viewer_AppendScript(Plugin::GetTemplateWebPath('freelancer').'assets/js/init.js');
        
        $aFilter = [];
        if($oOrder->getUserId() != $this->oUserCurrent->getId()){
            $aFilter =  ['user_id'=> $this->oUserCurrent->getUserId()]; 
        }else{
            $oOrder->setIsCreator(1);
        }
        //$this->loadOrderComments($oOrder, $aFilter);
        
        if(!$this->Rbac_IsAllow('response_create', 'freelancer',['no_stat' => 1])){
            $oOrder->setForbidComment(1);
        } 
        
        $this->SetTemplateAction('view');
        $this->Viewer_Assign('oOrder', $oOrder);
    } 
    
     
    private function loadOrderComments(&$oOrder, $aFilter = []){
        
       if (!Config::Get('module.comment.nested_page_reverse') and Config::Get('module.comment.use_nested') and Config::Get('module.comment.nested_per_page')) {
            $iPageDef = ceil($this->Comment_GetCountCommentsRootByTargetId($oOrder->getOrderId(),
                    'topic') / Config::Get('module.comment.nested_per_page'));
        } else {
            $iPageDef = 1;
        }
        $aFilter =  array_merge($aFilter, [
            'target_type'=>'order',
            'target_id' => $oOrder->getOrderId()            
        ]);
        $iPage = getRequest('cmtpage', 1) ? (int)getRequest('cmtpage', 1) : $iPageDef;
        
        //$aReturn = $this->Comment_GetCommentsByFilter($aFilter, [], $iPage, Config::Get('plugin.freelancer.response.per_page'));
        $aReturn = $this->Comment_GetCommentsByTargetId($oOrder->getOrderId(), 'order', $iPage, Config::Get('plugin.freelancer.response.per_page'));
        //print_r($aReturn);
        
        $oOrder->setCountComment(sizeof($aReturn['comments']));
        $iMaxIdComment = $aReturn['iMaxIdComment'];
        
        $iNoCreator = false;
        if($oOrder->getUserId() != $this->oUserCurrent->getId()){
            $iNoCreator = true;
        }
        $iCountResp=0;
        foreach($aReturn['comments'] as $k => $oComm){
            if($iNoCreator and $oComm->getUserId() != $oOrder->getUserId() and $oComm->getUserId() != $this->oUserCurrent->getId()){
                unset($aReturn['comments'][$k]);
                if(!$oComm->getCommentPid()){
                    continue;
                }
            }
            if(!$oComm->getCommentPid()){
                $iCountResp++;
            }
        }
        
        $oOrder->setCountComment($iCountResp);
        
        $aPaging = $this->Viewer_MakePaging($aReturn['count'], $iPage,
            Config::Get('plugin.freelancer.response.per_page'), Config::Get('plugin.freelancer.pagination.pages_count'), '');
        $this->Viewer_Assign('pagingComments', $aPaging);
        
        $this->Viewer_Assign('comments', $aReturn['comments']);
        $this->Viewer_Assign('lastCommentId', $iMaxIdComment);
    }
    
    public function EventRemove() {
        $iIdOrder = $this->GetParam(0);
        if(!$oOrder = $this->PluginFreelancer_Order_GetOrderByOrderId($iIdOrder)){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_page'),[],true);
            Router::LocationAction('order/search');
        }
        if(!$this->oUserCurrent->isAdministrator() and $this->oUserCurrent->getId() != $oOrder->getUserId()){
            $this->Message_AddError("Вы не можете удалить заказ: ".$oOrder->getTitle(),'',true);
            Router::LocationAction('order/search');
        }      
        if(!$oOrder->Delete()){
            $this->Message_AddError("Не возможно удалить заказ: ".$oOrder->getTitle(), '. Системная ошибка',true);
            Router::LocationAction('order/search');
        }else{
            $this->Message_AddNotice("Заказ ".$oOrder->getTitle(). ' удален','',true);
        }
        
        Router::LocationAction('order/search');
    }
        
    public function EventEdit() 
    {
        $this->Component_Add('freelancer:media');
        $this->Component_Add('freelancer:specialization-tabs');       
        
        $this->Viewer_AppendScript(Plugin::GetTemplateWebPath('freelancer').'assets/js/init.js');
        if(!$this->oUserCurrent){
            Router::ActionError($this->Lang_Get('plugin.freelancer.errors.no_auth'));
        }
        
        if(!$this->oUserCurrent->isAdministrator()){
            if(!$this->Rbac_IsAllow('create_order','freelancer',['no_stat' => true])){
                $this->Message_AddError($this->Rbac_GetMsgLast(),'',true);
                Router::LocationAction('error');
            }
        }
           
        $iIdOrder = $this->GetParam(0);
        if(!$oOrder = $this->PluginFreelancer_Order_GetOrderByFilter( array('order_id' => $iIdOrder) )){
            $oOrder = Engine::GetEntity('PluginFreelancer_ModuleOrder_EntityOrder');
        }
         
        $this->Hook_Run('freelancer_order_edit', ['oOrder' => &$oOrder]);
        
        //print_r($oOrder);
        /*
         * Подставляем данные пользователя если он авторизирован
         */
        if($this->oUserCurrent){
            if(!$oGeoTarget = $this->Geo_GetTargetByTarget('order', $oOrder->getOredrId())){
                $oGeoTarget = $this->Geo_GetTargetByTarget('user', $this->oUserCurrent->getId());
            }
            
            
            $oOrder->setGeoTarget($oGeoTarget);
        }
   
        if(isPost()){ 
            
            $oOrder->setTitle( getRequest('title') );
            
            $oOrder->setSpecialization( getRequest('specialization') );
                  
            $oOrder->setTextAbout( getRequest('text_about') );
            
            $oOrder->setBudjet( getRequest('budjet') );
            
            
            ///$oGeoTarget = $oOrder->setGeoData( getRequest('geo') );       
           // print_r(getRequest('geo'));
            //print_r($oOrder);
        
            $oOrder->setUserId( $this->oUserCurrent->getId());
            
            
            if($oOrder->_Validate()){  print_r($oOrder->_getData());
                if($oOrder->Save()){
                    Router::LocationAction($this->sCurrentAction.'/'.$oOrder->getOrderId());
                }
            }else{
                foreach ($oOrder->_getValidateErrors() as $sError){
                    $this->Message_AddError($sError[0]);
                }
            }
            
        }
        
        $this->Hook_Run('order_edit_event_end');
        
        
        $this->Viewer_Assign('oOrder', $oOrder);
        
        $this->Viewer_Assign('oUser', $this->oUserCurrent);
        
        $this->SetTemplateAction('add');
        
    }   
    
   public function EventChoose() {
        $iIdOrder = (int)$this->sCurrentEvent;
        $iIdResp = $this->GetParam(1);
        
        if( !$oOrder = $this->PluginFreelancer_Order_GetOrderByOrderId($iIdOrder) ){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_order'),[],true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        
        if( !$oBid = $this->PluginFreelancer_Order_GetBidById($iIdResp)  ){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_response'),[],true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        if(!$oOrder->getUserId() == $this->oUserCurrent->getId() and !$this->oUserCurrent->isAdministrator()){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.noallow_edit'),[],true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        $oOrder->setMasterId($oBid->getUserId());
        
        if(!$oOrder->Save()){
            $this->Message_AddError($this->Lang_Get('common.error.save'), [] , true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        $this->Message_AddNotice($this->Lang_Get('plugin.freelancer.saved'), [] , true);
        Router::LocationAction('order/'.$oOrder->getOrderId());
    }
    
    public function EventCancelMaster() {
        $iIdOrder = (int)$this->sCurrentEvent;
        if( !$oOrder = $this->PluginFreelancer_Order_GetOrderByOrderId($iIdOrder) ){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_order'),[],true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        if(!$oOrder->getUserId() == $this->oUserCurrent->getId() and !$this->oUserCurrent->isAdministrator()){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.noallow_edit'),[],true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        $oOrder->setMasterId(null);
        if(!$oOrder->Save()){
            $this->Message_AddError($this->Lang_Get('common.error.save'), [] , true);
            Router::LocationAction('order/'.$oOrder->getOrderId());
        }
        $this->Message_AddNotice($this->Lang_Get('plugin.freelancer.saved'), [] , true);
        Router::LocationAction('order/'.$oOrder->getOrderId());
    }
    
    
    public function canCreateOrder(&$oOrder) {
        if($this->oUserCurrent->isAdministrator()){
            return true;
        }
        if($this->Storage_Get('order_create')){
            $oOrder->_setData(['_create_order' => 1]);
            return true;
        }
        if(!$this->Rbac_IsAllow('create_order','freelancer')){
            $this->Message_AddError($this->Rbac_GetMsgLangPermissions(),[],true);
            Router::LocationAction('error');
        }
        $oOrder->setStatus('start');
        $this->Storage_Set('order_create', 1);
        $oOrder->_setData(['_create_order' => 1]);
        return true;
    }
    
    
    public function canEditOrder($oOrder) {
        if($this->oUserCurrent->isAdministrator()){
            return true;
        }
        if($oOrder->getUserId() == $this->oUserCurrent->getId()){
            return true;
        }
        $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.noallow_edit'),[],true);
        Router::LocationAction('error');
    }
    
    public function canViewOrder($oOrder) {
        if($this->oUserCurrent->isAdministrator()){
            return true;
        }
        if($oOrder->getUserId() == $this->oUserCurrent->getId()){
            return true;
        }
        if(!$this->Rbac_IsAllow('view_order','freelancer')){
            $this->Message_AddError($this->Rbac_GetMsgLangPermissions(),[],true);
            Router::LocationAction('error');
        }
        return false;
    }
    
    
}