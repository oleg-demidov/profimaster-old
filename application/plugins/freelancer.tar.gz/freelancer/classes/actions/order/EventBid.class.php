<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionOrder_EventBid extends Event {

    public function AddBid() 
    {
        
        if($sText = getRequestStr('comment_text')){
            
            if(!$this->CheckBid($sText)){
                return;
            }
            $oBid = Engine::GetEntity('PluginFreelancer_Order_Bid');
            $oBid->setText($sText);
            $oBid->setPrice(getRequest('price'));
            $oBid->setOrderId(getRequest('order_id'));
            $oBid->setUserId($this->oUserCurrent->getId());
            if($oBid->_Validate()){
                if($oBid->Save()){
                    $this->Message_AddNotice('Отклик успешно добавлен');
                }
            }else{
                foreach($oBid->_getValidateErrors() as $aError){
                    $this->Message_AddError($aError[0],'',true);
                }   
            }
        }
        Router::LocationAction('order/'.getRequest('comment_target_id'));
    }
    
    public function EventAjaxAdd() {
        $this->Viewer_SetResponseAjax('json');
        if($sText = getRequestStr('bid_text')){
            if(!$this->CheckBid($sText) or !$this->CheckExist()){
                return;
            }
            $oBid = Engine::GetEntity('PluginFreelancer_Order_Bid');
            $oBid->setText($sText);
            $oBid->setPrice(getRequest('price'));
            $oBid->setOrderId(getRequest('order_id'));
            $oBid->setUserId($this->oUserCurrent->getId());
            if($oBid->_Validate()){
                if($oBid->Save()){
                    $this->Viewer_AssignAjax('res',1);
                    $this->Message_AddNotice('Отклик успешно добавлен');
                }
            }else{
                foreach($oBid->_getValidateErrors() as $aError){
                    $this->Message_AddError($aError[0]);
                }   
            }
        }
    }
    
    public function EventAjaxEdit() {
        $this->Viewer_SetResponseAjax('json');
        if($sText = getRequestStr('bid_text')){
            if(!$this->CheckBid($sText)){
                return;
            }
            
            if(!$oBid = $this->PluginFreelancer_Order_GetBidById(getRequest('bid_id'))){
                $this->Message_AddErrorSingle($this->Lang_Get('plugin.freelancer.errors.no_create_response_more'));
                return false;     
            }
            $oBid->setText($sText);
            $oBid->setPrice(getRequest('price'));
            if($oBid->_Validate()){
                if($oBid->Save()){
                    $this->Viewer_AssignAjax('res',1);
                    $this->Message_AddNotice('Отклик успешно изменен');
                }
            }else{
                foreach($oBid->_getValidateErrors() as $aError){
                    $this->Message_AddError($aError[0]);
                }   
            }
        }
    }
    
    public function CheckExist() {
        if($oBid = $this->PluginFreelancer_Order_GetBidByOrderIdAndUserId(
                getRequest('order_id'),$this->oUserCurrent->getId())){
            $this->Message_AddErrorSingle($this->Lang_Get('plugin.freelancer.errors.no_create_response_more'));
            return false;                
        }
        
        return true;
    }
    
    public function CheckBid($sText) {
        
        if (!$this->User_IsAuthorization()) {
            $this->Message_AddErrorSingle($this->Lang_Get('common.error.need_authorization'));
            return false;
        }
        if(!$oOrder = $this->PluginFreelancer_Order_GetOrderByOrderId(getRequest('order_id'))){
            $this->Message_AddErrorSingle($this->Lang_Get('freelancer.errors.no_order'));
            return false;
        }
        if ($oOrder->getMaserId()) {
            $this->Message_AddErrorSingle($this->Lang_Get('freelancer.errors.master_already_check'));
            return false;
        }   
        
        
        return true;
    }
        
   public function EventAjaxRemove() {
        $this->Viewer_SetResponseAjax('json');
        $iIdBid = getRequest('idBid');
        
        if( !$oBid= $this->PluginFreelancer_Order_GetBidById($iIdBid)  ){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.no_response'));
            return;
        }
        if(!$this->oUserCurrent->getId() == $oBid->getUserId() and !$this->oUserCurrent->isAdministrator()){
            $this->Message_AddError($this->Lang_Get('plugin.freelancer.errors.noallow_edit'));
            return;
        }
       
        if($oBid->Delete()){
            $this->Message_AddNotice($this->Lang_Get('plugin.freelancer.bid_is_deleted'));  
            $this->Viewer_AssignAjax('res',1);
        }else{
             $this->Viewer_AssignAjax('res',0);
        }
    }
    
    public function EventGetAjaxForm() {
        $this->Viewer_SetResponseAjax('json');
        $iIdBid = getRequest('idBid');
        if(!$oBid = $this->PluginFreelancer_Order_GetBidById($iIdBid)){
            $this->Message_AddErrorSingle($this->Lang_Get('freelancer.errors.no_bid'));
            return false;
        }
        if(!$oOrder = $oBid->getOrder()){
            $this->Message_AddErrorSingle($this->Lang_Get('freelancer.errors.no_order'));
            return false;
        }
        $oViewer = $this->Viewer_GetLocalViewer();
        $oViewer->Assign('oOrder', $oOrder,true);
        $oViewer->Assign('oBid', $oBid,true);
        $this->Viewer_AssignAjax('sForm', $oViewer->Fetch("component@freelancer:bid.form"));
        $this->Viewer_AssignAjax('iBidId', $iIdBid);
    }
    
    
}