<?php


/**
 * Description of ActionOrder
 *
 * @author oleg
 */
class PluginFreelancer_ActionFreelancer extends ActionPlugin{
    
    protected $oUserCurrent;
    
    protected function RegisterEvent() {
        
        $this->RegisterEventExternal('FreelancerSearch','PluginFreelancer_ActionFreelancer_EventFreelancerSearch');
        $this->AddEventPreg('/^search$/i','/^(page([0-9]+))?/i','FreelancerSearch::EventSearch'); 
        
        $this->RegisterEventExternal('Ajax','PluginFreelancer_ActionFreelancer_EventAjax');       
        $this->AddEventPreg('/^ajax$/i','/^media$/i','/^submit-insert$/i','Ajax::EventMediaSubmitInsert');
        $this->AddEventPreg('/^ajax$/i','/^media$/i','/^upload-link$/i','Ajax::EventMediaUploadLink');
    }

    public function Init() {
        //$this->SetDefaultEvent('edit');
        $this->oUserCurrent =  $this->User_GetUserCurrent();        
    }
}