<?php
/**
 * BlockNetworksapphelp.class.php
 * @author: Roman Revin <xgismox@gmail.com>
 * @date  : 02.07.13
 */

class PluginFreelancer_BlockDefaultGeo extends Block
{
    private $plugin;

    public function Exec()
    {
        print_r(11112);
        return true;
    }
}