DELIMITER $$
CREATE FUNCTION `get_distance`(`lat1` DECIMAL(10,8) UNSIGNED, `long1` DECIMAL(10,8) UNSIGNED, `lat2` DECIMAL(10,8) UNSIGNED, `long2` DECIMAL(10,8) UNSIGNED) 
RETURNS int(10) unsigned
BEGIN
    RETURN (sqrt(pow(abs(long1-long2),2)+pow(abs(lat1-lat2),2))*100000);
END$$
DELIMITER ;