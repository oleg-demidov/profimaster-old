
jQuery(function($) { 
    $('.js-ymap-enable-map').searchToggleMap(ls.registry.get('ymapsOptions'));    
});
