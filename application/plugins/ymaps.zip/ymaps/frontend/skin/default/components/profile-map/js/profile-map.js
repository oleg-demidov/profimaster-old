
jQuery(function($) { 
    $('.ymaps-modal-map').modalMap(ls.registry.get('ymapsOptions'));    
});

