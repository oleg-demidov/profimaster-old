<?php

$config['geo'] = [
    'enable' => true,
    'country_code' => 'kz',
    'results' => 10
];


return $config;