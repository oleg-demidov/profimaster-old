<?php


/**
 * Description of yd
 *
 * @author oleg
 */


class PluginYmaps_ModuleGeo extends ModuleORM{
        
    public function Init() {
        parent::Init();
    }
    
    public function GetBehaviorFor($sTargetType) {
        return array(
            'class'=>'PluginYmaps_ModuleGeo_BehaviorEntity',
            'target_type'=>$sTargetType,
            'field_name' =>Config::Get('plugin.ymaps.options.field_name')
        );
    }
    
    /*
     * Обеспечивает фильтр типа ['#ymaps' => [lat, long, distance]] где
     * lat долгота
     * long широта
     * distance радиус
     * 
     * Фильтрует результат. Возвращает сущности входящие в круг. Необходима Mysql функция get_distance см dump_function.sql
     */
    
    /*public function RewriteFilter($aFilter, $sEntityFull, $sTargetType)
    {
        $oEntitySample = Engine::GetEntity($sEntityFull);

        if (!isset($aFilter['#join'])) {
            $aFilter['#join'] = array();
        }

        if (!isset($aFilter['#select'])) {
            $aFilter['#select'] = array();
        }

        if (array_key_exists('#ymaps', $aFilter)) {
            $aMapFilter = $aFilter['#ymaps'];           
            if (!is_array($aMapFilter)) {
                return $aFilter;
            }
            
            $oGeoTable = MapperORM::GetTableName(Engine::GetEntity('PluginYmaps_Geo_Geo'));
            
            $sJoin = "JOIN " . $oGeoTable . " geo ON
					t.`{$oEntitySample->_getPrimaryKey()}` = geo.target_id and
					category.target_type = '{$sTargetType}' and
                                        `get_distance`(geo.lat, geo.long, ?d, ?d) < ?d
                                        ";
            $aFilter['#join'][$sJoin] = $aMapFilter;
            if (count($aFilter['#select'])) {
                $aFilter['#select'][] = "distinct t.`{$oEntitySample->_getPrimaryKey()}`";
            } else {
                $aFilter['#select'][] = "distinct t.`{$oEntitySample->_getPrimaryKey()}`";
                $aFilter['#select'][] = 't.*';
            }
        }
        return $aFilter;
    }    */
    

    /**
     * Переопределяем метод для возможности цеплять свои кастомные данные при ORM запросах - свойства
     *
     * @param array $aResult
     * @param array $aFilter
     * @param string $sTargetType
     */
    public function RewriteGetItemsByFilter($aResult, $aFilter, $sTargetType)
    {
        if (!$aResult) {
            return;
        }
        /**
         * Список на входе может быть двух видов:
         * 1 - одномерный массив
         * 2 - двумерный, если применялась группировка (использование '#index-group')
         *
         * Поэтому сначала сформируем линейный список
         */
        if (isset($aFilter['#index-group']) and $aFilter['#index-group']) {
            $aEntitiesWork = array();
            foreach ($aResult as $aItems) {
                foreach ($aItems as $oItem) {
                    $aEntitiesWork[] = $oItem;
                }
            }
        } else {
            $aEntitiesWork = $aResult;
        }

        if (!$aEntitiesWork) {
            return;
        }
        /**
         * Проверяем необходимость цеплять категории
         */
        if (isset($aFilter['#with']['#ymaps'])) { 
            $this->AttachGeoForTargetItems($aEntitiesWork, $sTargetType);
        }
    }

    /**
     * Цепляет для списка объектов геокоординаты
     *
     * @param array $aEntityItems
     * @param string $sTargetType
     */
    public function AttachGeoForTargetItems($aEntityItems, $sTargetType)
    {
        if (!is_array($aEntityItems)) {
            $aEntityItems = array($aEntityItems);
        }
        $aEntitiesId = array();
        foreach ($aEntityItems as $oEntity) {
            $aEntitiesId[] = $oEntity->getId();
        }
        /**
         * Получаем геокоординаты для всех объектов
         */
        $oGeoTable = MapperORM::GetTableName(Engine::GetEntity('PluginYmaps_Geo_Geo'));

        $aGeos = $this->GetCategoryItemsByFilter(array(
            'target_type' => $sTargetType,
            'target_id in' => $aEntitiesId,
            '#index-group' => 'target_id'
        ));
        /**
         * Собираем данные
         */
        foreach ($aEntityItems as $oEntity) {
            if (isset($aGeos[$oEntity->_getPrimaryKeyValue()])) {
                $oEntity->_setData(array('_ymaps' => $aGeos[$oEntity->_getPrimaryKeyValue()]));
            } else {
                $oEntity->_setData(array('_ymaps' => array()));
            }
        }
    }

}