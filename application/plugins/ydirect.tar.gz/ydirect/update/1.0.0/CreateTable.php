<?php


/**
 * Description of CreateTable
 *
 * @author oleg
 */

class PluginYdirect_Update_CreateTable extends ModulePluginManager_EntityUpdate {
	/**
	 * Выполняется при обновлении версии
	 */
    public function up() {
        $this->Logger_Notice(1);
        if (!$this->isTableExists('prefix_ydirect_ydirect_campaign')) {
            if($this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump_campaign.sql')){
                return true;
            }
        }
        if (!$this->isTableExists('prefix_ydirect_ydirect_adgroup')) {
            if($this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump_adgroup.sql')){
                return true;
            }
        }
        if (!$this->isTableExists('prefix_ydirect_ydirect_ads')) {
           if($this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump_ads.sql')){
                return true;
            }
        }
        if (!$this->isTableExists('prefix_ydirect_ydirect_keyword')) {
            if($this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump_keywords.sql')){
                return true;
            }
        }
        if (!$this->isTableExists('prefix_ydirect_ydirect_geo')) {
            if($this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump_geo.sql')){
                return true;
            }
        }
        if (!$this->isTableExists('prefix_ydirect_ydirect_geotarget')) {
             if($this->exportSQL(Plugin::GetPath(__CLASS__).'/update/1.0.0/dump_geotarget.sql')){
                return true;
            }
        }
        return false;
    }

	/**
	 * Выполняется при откате версии
	 */
	public function down() {
            if ($this->isTableExists('prefix_ydirect_ydirect_campaign')){
		$this->exportSQLQuery('DROP TABLE prefix_ydirect_ydirect_campaign');
            }
	}
}