CREATE TABLE `prefix_ydirect_ydirect_keyword` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `campaign_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ykeyword_id` bigint(20) UNSIGNED DEFAULT NULL,
  `adgroup_id` int(11) UNSIGNED DEFAULT NULL,
  `bid` int(11) DEFAULT '1',
  `value` varchar(50) NOT NULL,
  `active` tinyint(1) DEFAULT '0',
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `category_id` (`campaign_id`),
    KEY `adgroup_id` (`adgroup_id`);
) ENGINE=InnoDB DEFAULT CHARSET=utf8;