jQuery(function($) {
    tabsInit();
});

function tabsInit(){
    $('.js-my-tabs-keywords').lsTabs();
}