(function($) {
    "use strict";

    $.widget( "livestreet.YdirectKeywords", $.livestreet.lsComponent, {
        /**
         * Дефол
         */
        options: {
            urls:{
                load: aRouter.formkeywords
            }
        },
        _create: function () {
            this._super();
            var _this = this;
            this.loadForm();
            this.element.change(function(){
                _this.loadForm();
            });
        },
        loadForm: function(){
            this._load( 'load', { category_id: $(this.element).val() }, 'onGetForm' );
        },
        onGetForm: function(r){
            console.log(r)
            $('div.keywords > div.ls-block-content').html(r.form)
            tabsInit();
        }
    });
})( jQuery );

jQuery(document).ready(function($){
    $('select[name="specialization[]"]').YdirectKeywords();
});