<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of yd
 *
 * @author oleg
 */


class PluginAds_ModuleAds extends ModuleORM{
    
    public function Init() {
        parent::Init();
    }

    public function GetCampaignsList()
    {
        return $this->PluginAds_Ydirect_GetCampaignsList();
    }
    
}
