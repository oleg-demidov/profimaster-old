<?php

/**
 * Description of Anketa
 *
 * @author oleg
 */
class PluginYdirect_ModuleYdirect_MapperYdirect extends MapperORM{
    
   
    
}