<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of yd
 *
 * @author oleg
 */


class PluginYdirect_ModuleYdirect extends ModuleORM{
        
    public function Init() {
        parent::Init();
        $this->mapper = Engine::GetMapper(__CLASS__);
    }
    
    public function GetCampaignsList() {
        $aParams = [            
            'SelectionCriteria' =>[
                'Types' => ['TEXT_CAMPAIGN']
            ],
            'FieldNames' => [
                'NegativeKeywords', 'Name', 'Id'
            ]
        ];
        $url = Config::Get('plugin.ydirect.yd_url').'campaigns';
        if(!$oResult = $this->Response($url, 'get', $aParams)){
            return false;
        }
        return $oResult;
    }
    public function CreateCampaign($aParam) {
        $aParams = [            
            'Campaigns' =>[
                [
                    //'Name' => $aParams['name'],
                    'StartDate' => date('Y-m-d',(time()+(4*60*60))),
                    /*'DailyBudget' =>[
                        'Amount' => $iDailyBudget*1000000,
                        'Mode' => 'DISTRIBUTED'
                    ],*/
                    'Notification' => Config::Get('plugin.ydirect.campaigns.Notification'),
                    /*'NegativeKeywords' => [
                        'Items' => $aParams['aNKeywords']
                    ],*/
                    'TextCampaign' => [
                        'BiddingStrategy' => [
                            'Search' => [
                                'BiddingStrategyType' => 'HIGHEST_POSITION',
                                /*'AverageCpc' => [
                                    'AverageCpc' => (Config::Get('plugin.ydirect.campaigns.AverageCpc')*1000000),
                                    'WeeklySpendLimit' => Config::Get('plugin.ydirect.campaigns.WeeklySpendLimit')*1000000                
                                ]*/
                            ],
                            'Network' => [
                                'BiddingStrategyType' => 'NETWORK_DEFAULT',
                                'NetworkDefault' => [
                                    'BidPercent' => 100
                                ]
                            ]
                        ]
                    ],
                ]
            ]
        ];
        $aParams['Campaigns'][0] = array_merge($aParams['Campaigns'][0], $aParam);
        return $this->AddObj('campaigns', $aParams );
    }
    
    public function RemoveCampaign($iId ) {
        return $this->DeleteObj('campaigns', $iId );
    }
    
    public function CampaignUpdate($iId, $aParam =[] ) {
        $aParams = [            
            'Campaigns' =>[
                [
                    'Id' => $iId,                    
                ]
            ]
        ];
        $aParams['Campaigns'][0] = array_merge($aParams['Campaigns'][0], $aParam);
        return $this->UpdateObj('campaigns', $aParams);
    }
    
    public function AdGroupCreate($aParam) {
        $aParams = [            
            'AdGroups' =>[[]]
            ];
        $aParams['AdGroups'][0] = array_merge($aParams['AdGroups'][0], $aParam);
        
        return $this->AddObj('adgroups', $aParams );
    }
    
    public function AdGroupUpdate($iId, $aParam) {
        $aParams = [            
            'AdGroups' =>[[
                'Id' => $iId
            ]]
            ];
        $aParams['AdGroups'][0] = array_merge($aParams['AdGroups'][0], $aParam);
        return $this->UpdateObj('adgroups', $aParams);
    }
    
    public function AdGroupList($iCampaignId) {
        $aParams = [            
            'SelectionCriteria' =>[
                'Types' => ['TEXT_AD_GROUP'],
                'CampaignIds' => [$iCampaignId]
            ],
            'FieldNames' => [
                'NegativeKeywords', 'Name', 'Id'
            ]
        ];
        $url = Config::Get('plugin.ydirect.yd_url').'adgroups';
        if(!$oResult = $this->Response($url, 'get', $aParams)){
            return false;
        }
        return $oResult;
    }
    
    public function AdGroupDelete($iId ) {
        return $this->DeleteObj('adgroups', $iId );
    }
    
    public function AdsList($iIdAdGroup) {
        $aParams = [            
            'SelectionCriteria' =>[
                'Types' => ['TEXT_AD'],
                'AdGroupIds' => [$iIdAdGroup]
            ],
            'FieldNames' => [
                'AdGroupId', 'Id'
            ]
        ];
        $url = Config::Get('plugin.ydirect.yd_url').'ads';
        if(!$oResult = $this->Response($url, 'get', $aParams)){
            return false;
        }
        return $oResult;
    }
    
    public function AdsCreate($iIdAdGroup, $aParam) {
        $aParams = [            
            'Ads' =>[[
                'AdGroupId' => $iIdAdGroup,
            ]]
            ];   
        foreach($aParam as $k => $v){
           $aParams['Ads'][0][$k] = $v;
        }
        return $this->AddObj('ads', $aParams );
    }
    
    public function AdsModerate($iId) {
        $aParams = [            
            'SelectionCriteria' =>[
                'Ids' => [$iId]
            ]            
        ];
        $url = Config::Get('plugin.ydirect.yd_url').'ads';
        if(!$oResult = $this->Response($url, 'moderate', $aParams)){
            return false;
        }
        if(Config::Get('plugin.ydirect.debug_mode')){
            $this->Logger_Notice('ydirect ads: '.serialize($oResult));
        }
        return $oResult;
    }
    
    public function AdsUpdate($iIdAds, $aParam) {
        $aParams = [            
            'Ads' =>[[
                'Id' => $iIdAds,
            ]]
        ];
        foreach($aParam as $k => $v){
           $aParams['Ads'][0][$k] = $v;
        }
        return $this->UpdateObj('ads', $aParams);
    }
    
    public function AdsDelete($iId ) {
        return $this->DeleteObj('ads', $iId );
    }
   /*
    *  Keywords
    */
    
    public function KeywordsList($iIdAdGroup) {
        $aParams = [            
            'SelectionCriteria' =>[
                'AdGroupIds' => [$iIdAdGroup]
            ],
            'FieldNames' => [
                'Keyword', 'Id'
            ]
        ];
        $url = Config::Get('plugin.ydirect.yd_url').'keywords';
        if(!$oResult = $this->Response($url, 'get', $aParams)){
            return false;
        }
        return $oResult;
    }
    
    public function KeywordsCreate($iIdAdGroup, $aParam) {
        $aParams = [            
            'Keywords' =>[]
            ];   
        foreach($aParam as $v){
            $v['AdGroupId'] = $iIdAdGroup;
            $aParams['Keywords'][] = $v;
        }
        return $this->AddObj('keywords', $aParams );
    }
    
    public function KeywordsUpdate($iIdKeywords, $aParam) {
        $aParams = [            
            'Keywords' =>[[
                'Id' => $iIdKeywords,
            ]]
        ];
        foreach($aParam as $v){
            $aParams['Keywords'][0] = $v;
        }
        return $this->UpdateObj('keywords', $aParams);
    }
    
    public function KeywordsDelete($iId ) {
        return $this->DeleteObj('keywords', $iId );
    }
    
    public function DictionariesGet($aNames = ['GeoRegions']) {
        $aParams = [            
            "DictionaryNames" =>$aNames
        ];
        $url = Config::Get('plugin.ydirect.yd_url').'dictionaries';
        if(!$oResult = $this->Response($url, 'get', $aParams)){
            return false;
        }
        return $oResult;
    }
    
    protected function UpdateObj($sType, $aParams) {
        $url = Config::Get('plugin.ydirect.yd_url').$sType;
        if(!$oResult = $this->Response($url, 'update', $aParams)){
            return false;
        }
        foreach($oResult->result->UpdateResults as $oAddResult){
            if(property_exists($oAddResult,'Errors')){
                $this->Logger_Error('ydirect update'.$sType.': '.serialize($oAddResult));
                return false;
            }
        }
        if(Config::Get('plugin.ydirect.debug_mode')){
            $this->Logger_Notice('ydirect '.$sType.': '.serialize($oResult));
        }
        return $oResult->result->UpdateResults;
    }
    
    protected function DeleteObj($sType, $iId ) {
        $aParams = [            
            'SelectionCriteria' =>[
                'Ids' => [$iId]
            ]
            
        ];
        $url = Config::Get('plugin.ydirect.yd_url').$sType;
        if(!$oResult = $this->Response($url, 'delete', $aParams)){
            return false;
        }
        foreach($oResult->result->DeleteResults as $oDeleteResult){
            if(property_exists($oDeleteResult,'Errors')){
                $this->Logger_Error('ydirect '.$sType.': '.serialize($oDeleteResult));
                return false;
            }
        }
        if(Config::Get('plugin.ydirect.debug_mode')){
            $this->Logger_Notice('ydirect '.$sType.': '.serialize($oResult));
        }
        return $oResult->result->DeleteResults;
    }
    
    protected function AddObj($sType, $aParams ) {
        $url = Config::Get('plugin.ydirect.yd_url').$sType;
        if(!$oResult = $this->Response($url, 'add', $aParams)){
            return false;
        }
        foreach($oResult->result->AddResults as $oAddResult){
            if(property_exists($oAddResult,'Errors')){
                $this->Logger_Error('ydirect '.$sType.': '.serialize($oAddResult));
                return false;
            }
        }
        if(Config::Get('plugin.ydirect.debug_mode')){
            $this->Logger_Notice('ydirect '.$sType.': '.serialize($oResult));
        }
        return $oResult->result->AddResults;
    }
    
    protected function Response($url, $sMethod, $params=[]) {
        $token = Config::Get('plugin.ydirect.yd_token');
        $clientLogin = Config::Get('plugin.ydirect.yd_login');
        
        $headers = array(
           "Authorization: Bearer $token",                    // OAuth-токен. Использование слова Bearer обязательно
           //"Client-Login: $clientLogin",                      // Логин клиента рекламного агентства
           "Accept-Language: ru",                             // Язык ответных сообщений
           "Content-Type: application/json; charset=utf-8"    // Тип данных и кодировка запроса
        );
        
        $params = array(
            'method' => $sMethod,                                 // Используемый метод сервиса Campaigns
            'params' => $params
         );
        $body = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // Создание контекста потока: установка HTTP-заголовков и тела запроса
        $streamOptions = stream_context_create(array(
           'http' => array(
              'method' => 'POST',
              'header' => $headers,
              'content' => $body
           ),
           /*
           // Для полноценного использования протокола HTTPS можно включить проверку SSL-сертификата сервера API Директа
           'ssl' => array(
              'verify_peer' => true,
              'cafile' => getcwd().DIRECTORY_SEPARATOR.'CA.pem' // Путь к локальной копии корневого SSL-сертификата
           )
           */ 
        ));
        // Выполнение запроса, получение результата
        $sResult = file_get_contents($url, 0, $streamOptions);
        if ($sResult === false) { 
            $this->Logger_Error('ydirect '.$sMethod.': '."Ошибка выполнения запроса ydirect!". serialize($params)); 
            return false;
        }
        // Преобразование ответа из формата JSON
        $aResult = json_decode($sResult);

        if (isset($aResult->error)) {
            $apiErr = $aResult->error;
            $this->Logger_Error('ydirect '.$sMethod.': '."Ошибка API {$apiErr->error_code}: {$apiErr->error_string} - {$apiErr->error_detail} (RequestId: {$apiErr->request_id})". serialize($params));
            return false;
        }
        
        return $aResult;
    }
    
    public function GetUsersByPermissionCode($sCode) {
        return $this->Rbac_GetUsersByPermissionCode($sCode);
    }
    
    public function CheckPremissions(){
        $aUsers = $this->GetUsersByPermissionCode('ydirect');
        foreach($aUsers as $oUser){
            $oAdGroup = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityAdGroup');
        }
        
    }
}