<?php


class PluginYdirect_ModuleYdirect_EntityCampaign extends EntityORM
{
    protected $aValidateRules=array(
        array('name','string','max'=>2000,'min'=>3),
        array('average_cpc, weekly_spend_limit','number','max'=>20000,'min'=>1)
    );
    
    protected $aRelations = array(
        'ad_group'=>array(EntityORM::RELATION_TYPE_HAS_ONE,'PluginYdirect_ModuleYdirect_EntityAdGroup','campaign_id'),
        'keywords'=>array(EntityORM::RELATION_TYPE_HAS_MANY,'PluginYdirect_ModuleYdirect_EntityKeyword','campaign_id')
    );
    
    protected function beforeDelete()
    {
        if ($bResult = parent::beforeDelete()) {
            $bResult = $this->PluginYdirect_Ydirect_RemoveCampaign((int)$this->getYcampaignId());
        }
        return $bResult;
    }
    
    protected function beforeSave()
    {
        
        if ($bResult = parent::beforeSave()) {
            
            if($this->getActive()){
                $aParams = [
                    'Name' => $this->getName(),
                    'NegativeKeywords' => [
                        'Items' => explode(',', $this->getNegativeKeywords())
                    ]
                ];
                if (!$this->getYcampaignId()) {
                    $bResult = $this->PluginYdirect_Ydirect_CreateCampaign($aParams);
                    $this->setYcampaignId($bResult[0]->Id);
                }else{
                    $bResult = $this->PluginYdirect_Ydirect_CampaignUpdate($this->getYcampaignId(),$aParams);
                }
                $this->KeywordsSave();
            }elseif($this->getYcampaignId()){
                if($bResult = $this->PluginYdirect_Ydirect_RemoveCampaign((int)$this->getYcampaignId())){
                    $this->setYcampaignId(0);                
                }                
            }
        }
        return $bResult;
    }
    
    public function setKeywords($sKeywords) {
        $this->_setData(['keywords_for_save' => $sKeywords]);
    }
    
    public function setBid($iBid) {
        $this->_setData(['bid_for_save' => $iBid]);
    }
    
    public function getBid() {
        return $this->_getDataOne('bid_for_save');
    }
    
    public function KeywordsSave() {
        $sKeywords = $this->_getDataOne('keywords_for_save');
        $aKeywordsOrig = $this->getKeywords();
        $sKeywords = trim($sKeywords).',';
        $aSKeywords = preg_split("/[\s,]+/", $sKeywords, -1, PREG_SPLIT_NO_EMPTY );
        foreach($aKeywordsOrig as $k => $oKeywordOrig){
            if(($key = array_search($oKeywordOrig->getValue(), $aSKeywords)) === false){
                $oKeywordOrig->Delete();
                unset($aKeywordsOrig[$k]);
            }else{
                unset($aSKeywords[$key]);
            }
        }        
        $aKeywordsRes = $aKeywordsOrig;
        foreach($aSKeywords as $sKeyword){
            $oKeyword = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityKeyword');
            $oKeyword->setValue($sKeyword);
            $aKeywordsRes[] = $oKeyword;
            
        }
        //print_r($aKeywordsRes);
        
        foreach($aKeywordsRes as $oKeywordRes){
            $oKeywordRes->setCampaignId($this->getId());
            $oKeywordRes->setActive(0);
            $oKeywordRes->Save();
        }
    }
}