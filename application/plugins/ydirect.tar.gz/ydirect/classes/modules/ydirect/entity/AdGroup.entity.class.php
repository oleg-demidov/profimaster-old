<?php


class PluginYdirect_ModuleYdirect_EntityAdGroup extends EntityORM
{
    protected $aValidateRules=array(
        array('name','string','max'=>2000,'min'=>3),
        array('average_cpc, weekly_spend_limit','number','max'=>20000,'min'=>1)
    );
    
    protected $aRelations = array(
        'user'=>array(EntityORM::RELATION_TYPE_BELONGS_TO,'ModuleUser_EntityUser','user_id'),
        'ads'=>array(EntityORM::RELATION_TYPE_HAS_MANY,'PluginYdirect_ModuleYdirect_EntityAds','adgroup_id'),
        'keywords'=>array(EntityORM::RELATION_TYPE_HAS_MANY,'PluginYdirect_ModuleYdirect_EntityKeyword','adgroup_id'),
    );
    
    protected function beforeDelete()
    {
        if ($bResult = parent::beforeDelete()) {
            $bResult = $this->AdGroupDelete($this->getYadgroupId());            
        }
        return $bResult;
    }
    
    protected function beforeSave()
    {
        if ($bResult = parent::beforeSave()) {
            if($this->getActive()){
                
                $aParams = [
                    'Name' => $this->getName(),
                    'NegativeKeywords' => [
                        'Items' => explode(',', $this->getNegativeKeywords())
                    ],
                    'RegionIds' => $this->getRegionIds()
                ];            
                if (!$this->getYadgroupId()) {   
                    $aParams['CampaignId'] = $this->getYcampaignId();
                    if($bResult = $this->PluginYdirect_Ydirect_AdGroupCreate($aParams)){
                        $this->setYadgroupId($bResult[0]->Id);                
                    }
                }else{
                    $bResult = $this->PluginYdirect_Ydirect_AdGroupUpdate($this->getYadgroupId(),$aParams);
                }
                if($this->getSaveKeywords()) $this->KeywordsSave();
            }else{
                if($this->getSaveKeywords()) $this->KeywordsSave();
                if($this->getYadgroupId()){
                    $aAds = $this->getAds();
                    foreach($aAds as $oAds){
                        $oAds->setActive(0);
                        $oAds->Save();
                    }
                    if($bResult = $this->PluginYdirect_Ydirect_AdGroupDelete($this->getYadgroupId())){
                        $this->setYadgroupId(null);
                    }
                }
            }
        }
        return $bResult;
    }
    
    public function setRegionIds($aRegionIds) {
        $this->_setData(['region_ids' => serialize($aRegionIds)]);
    }
    
    public function getRegionIds() {
        return unserialize($this->_getDataOne('region_ids'));
    }
    
    protected function AdGroupDelete($iId) {
        if(!$this->KeywordsDelete()){
            return false;
        }
        if(!$this->AdsDelete()){
            return false;
        }
        return $this->PluginYdirect_Ydirect_AdGroupDelete($this->getYadgroupId());
    }
        
    protected function AdsDelete() {
        $aAds = $this->PluginYdirect_Ydirect_GetAdsItemsByAdgroupId($this->getAdgroupId());
        foreach($aAds as $oAds){
            if(!$oAds->Delete()){
                return false;
            }
        }
        return true ;
    }
    
    protected function KeywordsDelete() {
        $aKeywords = $this->PluginYdirect_Ydirect_GetKeywordItemsByAdgroupId($this->getAdgroupId());
        foreach($aKeywords as $oKeyword){
            if(!$oKeyword->Delete()){
                return false;
            }
        }
        return true ;
    }
    public function getUrlEdit() {
        return Router::GetPathRootWeb().'admin/plugin/ydirect/ads/edit/'.$this->getUserId().'/'.$this->getCampaignId();
    }
    
    public function setKeywords($sKeywords) {
        $this->setSaveKeywords(1);
        $this->_setData(['keywords_for_save' => $sKeywords]);
    }
    
    public function setBid($iBid) {
        $this->_setData(['bid_for_save' => $iBid]);
    }
    
    public function getBid() {
        if(!$nBid = $this->_getDataOne('bid_for_save')){
            $nBid = Config::Get('plugin.ydirect.default_bid');
        }
        return ;
    }
    
    public function KeywordsSave() {
        $sKeywords = $this->_getDataOne('keywords_for_save');
        $aKeywordsOrig = $this->getKeywords();
        $sKeywords = trim($sKeywords).',';
        $aSKeywords = preg_split("/[\s,]+/", $sKeywords, -1, PREG_SPLIT_NO_EMPTY );
        
        if($oCampaign = $this->PluginYdirect_Ydirect_GetCampaignById($this->getCampaignId())){
            $aKeywordsDef = $oCampaign->getKeywords();
            foreach($aKeywordsDef as $oKeywordDef){
                if(!in_array($oKeywordDef->getValue(), $aSKeywords)){
                    $aSKeywords[] = $oKeywordDef->getValue();
                }
            }
        }
        
        foreach($aKeywordsOrig as $k => $oKeywordOrig){
            if(($key = array_search($oKeywordOrig->getValue(), $aSKeywords)) === false){
                $oKeywordOrig->Delete();
                unset($aKeywordsOrig[$k]);
            }else{
                unset($aSKeywords[$key]);
            }
        }        
        $aKeywordsRes = $aKeywordsOrig;
        foreach($aSKeywords as $sKeyword){
            $oKeyword = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityKeyword');
            $oKeyword->setValue($sKeyword);
            $aKeywordsRes[] = $oKeyword;
            
        }
        
        //print_r($aKeywordsRes);
        
        foreach($aKeywordsRes as $oKeywordRes){
            $oKeywordRes->setAdgroupId($this->getId());
            $oKeywordRes->setYadgroupId($this->getYadgroupId());
            $oKeywordRes->setActive($this->getActive());
            $oKeywordRes->setBid($this->getBid());
            $oKeywordRes->Save();
        }
    }
}