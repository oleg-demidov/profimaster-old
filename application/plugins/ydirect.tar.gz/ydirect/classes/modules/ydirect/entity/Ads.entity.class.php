<?php


class PluginYdirect_ModuleYdirect_EntityAds extends EntityORM
{
    protected $aValidateRules=array(
        array('Title','string','max'=>33,'min'=>3),
        array('Text','string','max'=>75,'min'=>10),
    );
    
    protected $aRelations = array(
        'adgroup'=>array(EntityORM::RELATION_TYPE_BELONGS_TO,'PluginYdirect_ModuleYdirect_EntityAdGroup','adgroup_id'),
    );
    
    protected function beforeDelete()
    {
        if ($bResult = parent::beforeDelete()) {
            if($this->PluginYdirect_Ydirect_AdsDelete($this->getAdsId())){
                $bResult = true;
            }else{
                $bResult = false;
            }
        }
        return $bResult;
    }
    
    protected function beforeSave()
    {
        if ($bResult = parent::beforeSave()) {
            if(!$sType = $this->getType()){
                $sType = 'TextAd';
            }
            /*
             * На будущее тип обьявления пока только TextAd
             */
            if($this->getActive()){
                $aParams = [
                    $sType => [
                        'Text' => $this->getText(),
                        'Title' => $this->getTitle(),
                        'Href' => $this->getHref(),
                        'Mobile' => 'NO'
                    ]
                ];    
                if (!$this->getYadsId()) {

                    if($this->getYadgroupId() && $bResult = $this->PluginYdirect_Ydirect_AdsCreate($this->getYadgroupId(),$aParams)){
                        $this->setYadsId($bResult[0]->Id);   
                        $this->setStatus('moderate');
                        $this->PluginYdirect_Ydirect_AdsModerate($this->getYadsId());
                    }
                }else{
                    $bResult = $this->PluginYdirect_Ydirect_AdsUpdate($this->getYadsId(),$aParams);
                }     
            }elseif($this->getYadsId()){
                if($bResult = $this->PluginYdirect_Ydirect_AdsDelete($this->getYadsId())){
                    $this->setYadsId(0);                
                }
            }
        }
        return $bResult;
    }
}