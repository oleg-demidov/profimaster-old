<?php

/**
 * LiveStreet CMS
 * Copyright © 2013 OOO "ЛС-СОФТ"
 *
 * ------------------------------------------------------
 *
 * Official site: www.livestreetcms.com
 * Contact e-mail: office@livestreetcms.com
 *
 * GNU General Public License, version 2:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * ------------------------------------------------------
 *
 * @link http://www.livestreetcms.com
 * @copyright 2013 OOO "ЛС-СОФТ"
 * @author Serge Pustovit (PSNet) <light.feel@gmail.com>
 *
 */
class PluginYdirect_ActionFormkeywords extends ActionPlugin
{

    
    
    public function Init()
    {        
        $this->SetDefaultEvent('index');  
        $this->oUserCurrent = $this->User_GetUserCurrent();        
    }


    protected function RegisterEvent()
    {
        $this->AddEventPreg('/^(index)?$/i','EventIndex');
              
    }

    
    public function EventIndex()
    {
        $this->SetTemplate(false);
        $this->Viewer_SetResponseAjax('json');
        
        $aUserIds = $this->PluginYdirect_Ydirect_GetUsersByPermissionCode('ydirect');
        if(!in_array($this->oUserCurrent->getId(), $aUserIds)){
            $oViewer = $this->Viewer_GetLocalViewer();
            $oViewer->Assign('text', $this->Lang_Get('plugin.ydirect.error.no_ydirect_permission'), true);
            $this->Viewer_AssignAjax('form', $oViewer->Fetch('component@blankslate'));
            return;
        }        
        
        $aCategoryIds = getRequest('category_id');
        $aCampaigns = $this->PluginYdirect_Ydirect_GetCampaignItemsByFilter(['category_id in'  => $aCategoryIds, 'active' => 1]);
        if(sizeof($aCampaigns)){
            $oViewer = $this->Viewer_GetLocalViewer();
            $oViewer->Assign('aCampaigns', $aCampaigns, true);
            $this->Viewer_AssignAjax('form', $oViewer->Fetch('component@ydirect:keywords.ajax'));
        }else{            
            $oViewer = $this->Viewer_GetLocalViewer();
            $oViewer->Assign('text', $this->Lang_Get('plugin.ydirect.notice.no_campaigns_to_categories'), true);
            $this->Viewer_AssignAjax('form', $oViewer->Fetch('component@blankslate'));
        }
        
     }
}