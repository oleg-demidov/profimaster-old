<?php

/**
 * LiveStreet CMS
 * Copyright © 2013 OOO "ЛС-СОФТ"
 *
 * ------------------------------------------------------
 *
 * Official site: www.livestreetcms.com
 * Contact e-mail: office@livestreetcms.com
 *
 * GNU General Public License, version 2:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * ------------------------------------------------------
 *
 * @link http://www.livestreetcms.com
 * @copyright 2013 OOO "ЛС-СОФТ"
 * @author Maxim Mzhelskiy <rus.engine@gmail.com>
 *
 */
class PluginYdirect_ActionAdmin extends PluginAdmin_ActionPlugin
{

    /**
     * Объект УРЛа админки, позволяет удобно получать УРЛы на страницы управления плагином
     */
    public $oAdminUrl;
    public $oUserCurrent;

    public function Init()
    {
        //$this->Logger_Notice('22');
        $this->oAdminUrl = Engine::GetEntity('PluginAdmin_ModuleUi_EntityAdminUrl');
        $this->oAdminUrl->setPluginCode(Plugin::GetPluginCode($this));
        $this->oUserCurrent = $this->User_GetUserCurrent();
     //   $this->Viewer_AppendScript(Plugin::GetWebPath(__CLASS__) . 'frontend/js/admin.js');

        $this->SetDefaultEvent('ads');
    }

    /**
     * Регистрируем евенты
     *
     */
    protected function RegisterEvent()
    {
        /**
         * Для ajax регистрируем внешний обработчик
         */
        $this->RegisterEventExternal('Ads', 'PluginYdirect_ActionAdmin_EventAds');
        
        //$this->RegisterEventExternal('Bids', 'PluginFreelancer_ActionAdmin_EventBids');
       
        $this->AddEventPreg('/^ads/i', '/^(new|moderate|active)?$/i', 'Ads::EventList');
        //$this->AddEventPreg('/^ads/i', '/^(new)$/i', 'Ads::EventListNew');
        $this->AddEventPreg('/^ads/i', '/^(add|edit)$/i','/^([0-9]+)$/i','/^([0-9]+)?$/i', 'Ads::EventEdit');
        $this->AddEventPreg('/^ads-allow$/i','/^([0-9]+)?$/i', 'Ads::EventAjaxOrderAllow');
        $this->AddEventPreg('/^ads-remove$/i','/^([0-9]+)?$/i', 'Ads::EventAjaxOrderRemove');
        $this->AddEventPreg('/^ads-load$/i', 'Ads::EventAjaxOrderLoad');
        
        /*$this->AddEventPreg('/^bids$/i', '/^(new|publish|deleted)?$/i', 'Bids::EventList');
        $this->AddEventPreg('/^bid-allow$/i','/^([0-9]+)?$/i', 'Bids::EventAjaxBidAllow');
        $this->AddEventPreg('/^bid-remove$/i','/^([0-9]+)?$/i', 'Bids::EventAjaxBidRemove');
        $this->AddEventPreg('/^bid-load$/i', 'Bids::EventAjaxBidLoad');*/
        
    }

}