<?php

/**
 * LiveStreet CMS
 * Copyright © 2013 OOO "ЛС-СОФТ"
 *
 * ------------------------------------------------------
 *
 * Official site: www.livestreetcms.com
 * Contact e-mail: office@livestreetcms.com
 *
 * GNU General Public License, version 2:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * ------------------------------------------------------
 *
 * @link http://www.livestreetcms.com
 * @copyright 2013 OOO "ЛС-СОФТ"
 * @author Serge Pustovit (PSNet) <light.feel@gmail.com>
 *
 */
class PluginYdirect_ActionAds extends ActionPlugin
{

    
    
    public function Init()
    {        
        $this->SetDefaultEvent('index');  
        $this->oUserCurrent = $this->User_GetUserCurrent();        
        
    }


    protected function RegisterEvent()
    {
        $this->AddEventPreg('/^(index)?$/i','EventIndex');
              
    }

    
    public function EventIndex()
    {
        $this->SetTemplate(false);
        //$oCampaign = $this->PluginYdirect_Ydirect_GetCampaignByCategoryId(27);
        //$oCampaign = $this->PluginYdirect_Ydirect_GetCampaignByCampaignId(221271);
        //print_r($oCampaign->getAdGroup());
        //$oCampaign->Delete();
        //print_r($this->PluginYdirect_Ydirect_DeleteCampaign(220247));
        //print_r($this->PluginYdirect_Ydirect_GetCampaignsList());
        /*$aGeoData = $this->PluginYdirect_Ydirect_DictionariesGet();
        
        $aGeoRegions = $aGeoData->result->GeoRegions;
        
        foreach($aGeoRegions as $oGeoRegion){
            $oGeo = Engine::GetEntity('PluginYdirect_Geo_Geo');
            $oGeo->setParentId($oGeoRegion->ParentId);
            $oGeo->setGeoRegionType($oGeoRegion->GeoRegionType);
            $oGeo->setGeoRegionName($oGeoRegion->GeoRegionName);
            $oGeo->setGeoRegionId($oGeoRegion->GeoRegionId);
            $oGeo->Save();
        }*/
        
       // $aGeo = $this->PluginYdirect_Geo_GetGeoItemsByFilter(['parent_id'=>159]);
       // saveChild($aCountries[0], $aCountries[0]->getGeoRegionId());
        $aTree = $this->PluginYdirect_Geo_LoadTreeOfGeo(['country_id'=>159]); // parent kaz 166
        print_r($aTree);
        /*foreach($aGeo as $oGeo){
            echo $oGeo->getGeoRegionName(),'<br>';
            $oGeo->setCountryId(159);
            $oGeo->Save();
            $aGeoC = $this->PluginYdirect_Geo_GetGeoItemsByFilter(['parent_id'=> $oGeo->getGeoRegionId()]);
            foreach($aGeoC as $oGeoC){
                echo $oGeoC->getGeoRegionName(),'<br>';
                $oGeoC->setCountryId(159);
                $oGeoC->Save();
            }
        }*/
        //$oAdGroup = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityAdGroup');
        
        //$oAdGroup = $this->PluginYdirect_Ydirect_GetAdGroupByAdgroupId(2476560);
        /*print_r($oAdGroup->getAds());
        $oAdGroup->setName('test');
        $oAdGroup->setUserId(1);
        $oAdGroup->setNegativeKeywords('eee,ttt');
        //$oAdGroup->setCampaignId(221267);
        $oAdGroup->setRegionIds([159]);
        $oAdGroup->setStatus('stop');
        //$oAdGroup->Save();*/
        //$oAdGroup->Delete();
        //print_r($this->PluginYdirect_Ydirect_AdGroupList(221267));
        
        //$oKeyword = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityKeyword');
        //$oKeyword = $this->PluginYdirect_Ydirect_GetKeywordById();
        //$oKeyword->setValue('test');
        //$oKeyword->setAdgroupId($oAdGroup->getAdgroupId());
        //$oKeyword->setBid(1);
        //$oKeyword->Save();
        //$oKeyword->Delete();
       // print_r($this->PluginYdirect_Ydirect_KeywordsList($oAdGroup->getAdgroupId()));
        
        //$oAds = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityAds');
        //$oAdGroup = $this->PluginYdirect_Ydirect_GetAdsById(4);
        //$oAds->setText('test text test text');
        //$oAds->setTitle('test ads');
        //$oAds->setHref('http://gg.ht');
       // $oAds->setAdgroupId($oAdGroup->getAdgroupId());
        //$oAds->Save();
        //$oKeyword->Delete();
       // print_r($this->PluginYdirect_Ydirect_AdsList($oAdGroup->getAdgroupId()));
        //$oTargetAds = Engine::GetEntity('PluginYdirect_ModuleYdirect_EntityTrgetAds');
        
       
    }
}