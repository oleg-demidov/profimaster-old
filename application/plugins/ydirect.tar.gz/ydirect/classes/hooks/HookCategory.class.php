<?php

/**
 * Регистрация хука для вывода Profi анкет
 *
 * @package application.hooks
 * @since 1.0
 */
class PluginYdirect_HookCategory extends Hook
{
    /**
     * Регистрируем хуки
     */
    public function RegisterHook()
    {
        $this->AddHook('ydirect_after_save_category', 'SaveCategory', __CLASS__, 1000);
        $this->AddHook('ydirect_before_delete_category', 'DeleteCategory', __CLASS__, 1000);
        
        $this->AddHook('template_user_settings_specialization_end', 'AddKeywords');
        $this->AddHook('freelancer_user_event_specialization', 'AddKeywordsComponent');
        $this->AddHook('freelancer_user_aftersave_specialization', 'SaveKeywords');
    }

    /**
     * Сохранение специализации в админке
     */
    public function SaveCategory($aParams)
    {
        /*$oCategory = $this->Category_GetCategoryById(getRequest('category_id'));
        if(!$oCampaign = $this->PluginYdirect_Ydirect_GetCampaignByCategoryId(getRequest('category_id'))){
            $oCampaign = Engine::GetEntity('PluginYdirect_Ydirect_Campaign');            
        }
        $oCampaign->setName($oCategory->getTitle());
        $oCampaign->setCategoryId(getRequest('category_id'));
        $oCampaign->setKeywords(getRequest('keywords')[0]);
        $oCampaign->setNegativeKeywords(getRequest('negative_keywords'));
        $oCampaign->setActive(getRequest('active'));
        $aParams['bResult'] = $oCampaign->Save();*/
    }
    
    public function DeleteCategory($aParams)
    {
        if($oCampaign = $this->PluginYdirect_Ydirect_GetCampaignByCategoryId($aParams['category']->getId())){
            $aParams['bResult'] = $oCampaign->Delete();
        }else{
            $aParams['bResult'] = false;
        }
    }
    
    
    /*
     *  добавление специализации пользователю
     */
    public function AddKeywordsComponent($param) {
        $this->Component_Add('ydirect:keywords');
    }
    public function AddKeywords() {
        return $this->Viewer_Fetch('component@ydirect:keywords.block');
    }
    public function SaveKeywords($aParams) {
        $oUser = $aParams['oUser'];
        $aKeywords = getRequest('keywords');
        
        $aBeh = Config::Get('plugin.ydirect.ygeo_beh');
        $aBeh['target_type'] = 'user';
        $oUser->AttachBehavior('ygeo', $aBeh );
        $aGeoRegions = $oUser->ygeo->getGeos();
        $aRegionIds = [];
        foreach($aGeoRegions as $oGeoRegion){
            $aRegionIds[] = $oGeoRegion->getGeoRegionId();
        }
        
        foreach($aKeywords as $iCampaignId => $sKeywords){
            $oCampaign = $this->PluginYdirect_Ydirect_GetCampaignById($iCampaignId);
            if(!$oAdGroup = $this->PluginYdirect_Ydirect_GetAdGroupByFilter([
                            'campaign_id' => $iCampaignId, 
                            'user_id' => $oUser->getId()])){
                $oAdGroup = Engine::GetEntity('PluginYdirect_Ydirect_AdGroup');                
                $oAdGroup->setUserId($oUser->getId());
                $oAdGroup->setCampaignId($oCampaign->getId());
                $oAdGroup->setName($oUser->getProfileName());
                $oAdGroup->Save();
            }
            
            $aAds = $oAdGroup->getAds();
            if(sizeof($aAds)){
                $oAds = $aAds[0];
            }else{
                $oAds = Engine::GetEntity('PluginYdirect_Ydirect_Ads'); 
            }
            $sTitleAds = '';
            $sTextAds = '';
            if(is_array($aReqTitle = getRequest('title_ads'))){
                $sTitleAds = $aReqTitle[$iCampaignId];
            }
            if(is_array($aReqText = getRequest('text_ads'))){
                $sTextAds = $aReqText[$iCampaignId];
            }
            if(!$oAds->getActive()){
                $oAds->setTitle($sTitleAds);
                $oAds->setText($sTextAds);
                $oAds->setStatus('new');
                $oAds->setAdgroupId($oAdGroup->getId());
                $oAds->Save();
            }
            
            
            
            $oAdGroup->setYcampaignId($oCampaign->getYcampaignId());
            
            $oAdGroup->setRegionIds($aRegionIds);
            $oAdGroup->setKeywords($sKeywords);
            $oAdGroup->setActive(getRequest('adgroup_active'));
            $oAdGroup->Save();
        }
        return $this->Viewer_Fetch('component@ydirect:keywords');
    }
}