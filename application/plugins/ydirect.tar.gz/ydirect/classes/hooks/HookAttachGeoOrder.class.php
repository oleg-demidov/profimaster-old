<?php
/**
 * LiveStreet CMS
 * Copyright © 2013 OOO "ЛС-СОФТ"
 *
 * ------------------------------------------------------
 *
 * Official site: www.livestreetcms.com
 * Contact e-mail: office@livestreetcms.com
 *
 * GNU General Public License, version 2:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * ------------------------------------------------------
 *
 * @link http://www.livestreetcms.com
 * @copyright 2013 OOO "ЛС-СОФТ"
 * @author Maxim Mzhelskiy <rus.engine@gmail.com>
 *
 */

/**
 * Хуки
 */
class PluginYdirect_HookAttachGeoOrder extends Hook
{
    /**
     * Регистрация необходимых хуков
     */
    public function RegisterHook()
    {
        $this->AddHook('freelancer_order_edit', 'AttachGeoOrder');
        $this->AddHook('freelancer_init_order_module', 'AttachGeoOrderModule');
        $this->AddHook('freelancer_event_search_order', 'AttachFilterSearch');
    }

    /**
     * Добавляем в главное меню админки свой раздел с подпунктами
     */
    public function AttachGeoOrder($aParams)
    {
        $this->Component_Add('ydirect:geo');
        $oOrder = $aParams['oOrder'];
        $aBeh = Config::Get('plugin.ydirect.ygeo_beh');
        $aBeh['target_type'] = 'order';
        $oOrder->AttachBehavior('ygeo', $aBeh );
    }
    public function AttachGeoOrderModule($aParams)
    {   
        $oOrder = $aParams['module'];        
        $aBeh = Config::Get('plugin.ydirect.ygeo_beh_module');
        $aBeh['target_type'] = 'order';
        $oOrder->AttachBehavior('ygeo', $aBeh );
    }
    
    public function AttachFilterSearch($aParams)
    {   
        $this->Component_Add('ydirect:geo');
        unset($aParams['filter']['#join']);
        $aParams['filter']['#ygeo'] = getRequest('ygeo');
    }
}