<?php
/*

 * @author Oleg
 *
 */

class PluginFreelancer_ModuleSms_EntitySms extends EntityORM
{
    

}