<?php

class PluginFreelancer_ModuleFavourites_EntityFavourite extends EntityORM
{

}