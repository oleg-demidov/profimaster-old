<?php

class PluginFreelancer_ModuleKdb_EntityPost extends EntityORM
{

    
        
    
}