<?php

class PluginFreelancer_ModuleKdb extends ModuleORM
{

    /**
     * Инизиализация модуля
     */
    public function Init()
    {
        parent::Init();
        
    }

}