<?php


class PluginFreelancer_ModuleUser_EntitySettings extends EntityOrm
{
    
}