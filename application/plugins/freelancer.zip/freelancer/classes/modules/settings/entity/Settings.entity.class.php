<?php


class PluginFreelancer_ModuleSettings_EntitySettings extends EntityOrm
{
    
}