<?php

class PluginFreelancer_ModuleSettings extends ModuleOrm
{
    public function Init() {
        parent::Init();
    }
}