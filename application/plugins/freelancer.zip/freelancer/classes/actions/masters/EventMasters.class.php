<?php


/**
 * Description of EventTopic
 *
 * @author oleg
 */

class PluginFreelancer_ActionMasters_EventMasters extends Event {

    public function Init() {
        
    }   


    public function EventMasters() 
    {
        if(getRequest('form')){
            $url = $this->_getUrlByRequest();
            
            $aRequest = $this->_getRequestAllow();
            $sRequest = sizeof($aRequest)?"?". http_build_query($aRequest):"";
            
            Router::Location(Router::GetPath($url) . $sRequest);
        }
        
        $this->Component_Add('freelancer:master');
        $this->Component_Add('freelancer:search-form');
        
        $this->SetTemplateAction('masters');
        
        $aFilter = $this->_getFilterByParams();  
        
                
        $aOrder =[];
        
        if($sOrderRating = getRequest('sort_rating')){
            $aOrder['user_rating'] = $sOrderRating;
        }
        if($sOrderDate = getRequest('sort_date')){
            $aOrder['user_date_register'] = $sOrderDate;
        }
                
        $aFilter['#select'] = ['user_id', 'user_login','user_profile_avatar'];
        
        if($sQuery = getRequest('query')){
            $aFilter['name'] = "%{$sQuery}%";
        }        
        
        if($aFilter['geo_object']){
            $aFilter['geo_'.$aFilter['geo_object']->getType()] = $aFilter['geo_object']->getId();
        }
        
        $aMasters = $this->getMastersByFilter($aFilter, $aOrder);
        
        //print_r($aFilter);
        
        $aPaging = $this->Viewer_MakePaging($aMasters['count'], $aFilter['page'], 
            2/*Config::Get('plugin.freelancer.poisk.per_page')*/,
            Config::Get('plugin.freelancer.poisk.count_page_line'), 
            Router::GetPath('masters/'.$this->_getUrlByFilter($aFilter)),
            $this->_getRequestAllow());
        
        if(isset($aFilter['geo_object'])){
             $this->Viewer_Assign('oGeo', $aFilter['geo_object'] );
        }
        
        if(isset($aFilter['categories_entity'])){
            $this->Viewer_Assign('specializationSelected',$aFilter['categories_entity'] );
        }
        $this->Viewer_Assign('aMasters',$aMasters['collection'] );
        $this->Viewer_Assign('iMastersCount',$aMasters['count'] );
        $this->Viewer_Assign('aPaging',$aPaging );
    }
    
    public function EventMastersAjax() {
        
        $this->Viewer_SetResponseAjax('json');
        
        $aFilter = [];
        
        if (getRequestStr('city')) {
            $aFilter['geo_city'] = getRequestStr('city');
        } elseif (getRequestStr('region')) {
            $aFilter['geo_region'] = getRequestStr('region');
        } elseif (getRequestStr('country')) {
            $aFilter['geo_country'] = getRequestStr('country');
        }
        
        if($aCategories = getRequest('categories')){
            $aFilter['categories'] = $aCategories;
        }
        
        $sOrderWay = in_array(getRequestStr('order'), array('desc', 'asc')) ? getRequestStr('order') : 'desc';
        $sOrderField = in_array(getRequestStr('sort_by'), array(
            'user_rating',
            'user_date_register',
            'user_login',
            'user_profile_name'
        )) ? getRequestStr('sort_by') : 'user_rating';
                
        $aOrder =[$sOrderField => $sOrderWay];
        
        if (is_numeric(getRequestStr('page')) and getRequestStr('page') > 0) {
            $aFilter['page'] = getRequestStr('page');
        } else {
            $aFilter['page'] = 1;
        }
         
        $aFilter['#select'] = ['user_id', 'user_login','user_profile_avatar'];
        
        if($sQuery = getRequest('query')){
            $aFilter['name'] = "%{$sQuery}%";
        }        
        
        $aMasters = $this->getMastersByFilter($aFilter, $aOrder);
        
        //print_r($aFilter);
        $this->Logger_Notice(serialize($aFilter));
        
        $aPaging = $this->Viewer_MakePaging($aMasters['count'], $aFilter['page'], 
            2/*Config::Get('plugin.freelancer.poisk.per_page')*/,
            Config::Get('plugin.freelancer.poisk.count_page_line'), 
            Router::GetPath('masters'),
            $this->_getRequestAllow());
        
        
        
        $oViewer = $this->Viewer_GetLocalViewer();
        
        $oViewer->Assign('aMasters',$aMasters['collection'], true);
        $oViewer->Assign('iMastersCount',$aMasters['count'], true );
        $oViewer->Assign('aPaging',$aPaging , true);
        
        $this->Viewer_AssignAjax('iMastersCount', $aMasters['count']);
        $this->Viewer_AssignAjax('html', $oViewer->Fetch("component@freelancer:master.page"));
        
    }
    
    public function getMastersByFilter($aFilter, $aOrder) {
        
        $aOrder['field'] = $this->Rbac_GetUsersByPermissionCode('master_top');
         
        $aFilter['activate'] = 1;
        
        if(isset($aFilter['categories']) and sizeof($aFilter['categories'])){
            $aFilter['#category'] = end($aFilter['categories']);
        }
        
        $aFilter['not_in'] = array_merge(
                [1], // админ
                $this->Rbac_GetUsersByPermissionCode('employer'),
                $this->Rbac_GetUsersByPermissionCode('manager')); //print_r($aFilter);
   
        return $this->User_GetUsersByFilter($aFilter, $aOrder, $aFilter['page'] ,2/*Config::Get('plugin.freelancer.poisk.per_page')*/ );        
        
    }
    
}