

jQuery(function ($) {
    $('.js-profile-about').flEditor();alert(1)
});