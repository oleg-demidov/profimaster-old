(function($){
    "use strict";
    $.widget('freelancer.flSearchAjax', $.livestreet.lsSearchAjax, {
        options: {
            // Ссылки
            urls: {
                search: null
            },

            // Селекторы
            selectors: {
                submit: '.fl-search-form-but-submit',
                title: null,
                pages:".ls-pagination-item-link"
            },

            // Локализация
            i18n: {
                title: null
            },

            // Фильтры
            filters : [],

            // Парметры передаваемый при аякс запросе
            params : {}
        },
        
        _create: function () {
            
            this._super();
            
            this.elements.submit = $(this.option('selectors.submit'));
            
            this.elements.submit.off('click');
            
            this._on(this.elements.submit, {click:"update"});
            
            this.listenPages();
            
        },
        listenPages:function(){
            var _this = this;
            $(this.option('selectors.pages')).click(function(){
                _this.goPage($(this).html());
                return false;
            });
        },
        update: function() {
            for (var i = 0; i < this.option( 'filters' ).length; i++) {
                this.updateFilter( this.option( 'filters' )[i] );
            };
            
            this.option('params.page', undefined);

            this._trigger( 'beforeupdate', null, this );

            this._load( 'search', 'onUpdate' );
        },
        goPage:function(nPage){
            this.option('params.page', nPage);

            this._trigger( 'beforeupdate', null, this );

            this._load( 'search', 'onUpdate' );
        },
        onUpdate: function ( response ) {
            
            this.elements.list.html( $.trim( response.html ) );
            
            this.elements.result_count.html(response.iMastersCount)
            
            this.listenPages();

            this._trigger( 'afterupdate', null, { context: this, response: response } );
        }
    })
    
})(jQuery);