jQuery(function($) { 
   $('.js-master-specializations').lsDetails();
   $('.fl-favorite-tooltip').lsTooltip();
});