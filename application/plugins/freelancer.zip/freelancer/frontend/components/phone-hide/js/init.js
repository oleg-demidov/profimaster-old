jQuery(function ($) {
    $('.fl-phone-hide-linkshow').phoneHide();
});