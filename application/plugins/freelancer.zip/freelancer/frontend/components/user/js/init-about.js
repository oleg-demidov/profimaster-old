

jQuery(function ($) {
    $('.js-profile-about').lsEditor({
        sets:{
            about:  {
                toolbar: 'fullscreen'
            }
        }
    });
});