$('.js-bindremove-confirm').lsConfirm({
    message: "Вы уверены?"
});