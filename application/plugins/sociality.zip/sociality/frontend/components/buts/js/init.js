jQuery(function($) {
    $('.js-my-slider').lsSlider();
});