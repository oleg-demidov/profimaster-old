<?php
/**
 * Русский языковой файл
 */
return array(
    'Order buttons' => 'Порядок кнопок',
    'Order' => 'Порядок',
    'email_dublicate' => 'Найдена учетная запись с email - ом'
);