<?php

$config['$root$']['router']['page']['robopay'] = 'PluginRobokassa_ActionPayment';

return $config;
?>