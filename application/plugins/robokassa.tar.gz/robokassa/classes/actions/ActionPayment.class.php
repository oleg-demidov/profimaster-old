<?php


class PluginRobokassa_ActionPayment extends ActionPlugin
{

    public function Init()
    {
        
    }

    /**
     * Регистрируем евенты
     *
     */
    protected function RegisterEvent()
    {
        $this->AddEventPreg('/^index$/i', 'EventIndex');

    }


    /**********************************************************************************
     ************************ РЕАЛИЗАЦИЯ ЭКШЕНА ***************************************
     **********************************************************************************
     */


    protected function EventIndex(){
        
    }
}