<?php

class PluginRobokassa_ModulePayment extends ModuleORM
{
    public function Init() {
        parent::Init();
    }    

}