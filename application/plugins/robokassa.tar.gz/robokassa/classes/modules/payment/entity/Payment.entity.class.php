<?php


class PluginRobokassa_ModulePayment_EntityPayment extends EntityORM
{
    
}

?>